import type { LevelDef } from "@/game/levels";

export type SurfaceKind = "road" | "bridge" | "mud" | "broken" | "narrow";

export type TrackPoint = {
  x: number;
  y: number;
  z: number;
  tx: number;
  tz: number;
  rx: number;
  rz: number;
  width: number;
  kind: SurfaceKind;
};

export type TrackSample = {
  x: number;
  y: number;
  z: number;
  tx: number;
  tz: number;
  rx: number;
  rz: number;
  width: number;
  kind: SurfaceKind;
  lateral: number;
  dist: number;
  grad: number;
  s: number;
  yaw: number;
};

export type ObstacleKind = "rock" | "log" | "block" | "pit" | "mud" | "tree";

export type Obstacle = {
  kind: ObstacleKind;
  x: number;
  y: number;
  z: number;
  yaw: number;
  radius: number;
  solid: boolean;
};

export type CoinSpot = { x: number; y: number; z: number };

export type BuiltWorld = {
  track: TrackPoint[];
  length: number;
  obstacles: Obstacle[];
  coins: CoinSpot[];
};

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

export function buildWorld(level: LevelDef): BuiltWorld {
  const rng = mulberry32(level.seed);
  const n = level.segments;
  const kinds: SurfaceKind[] = Array.from({ length: n }, () => "road");
  const widths = Array.from({ length: n }, () => level.width);

  let cursor = 12;
  while (cursor < n - 10) {
    const roll = rng();
    if (roll < level.bridge) {
      const len = 5 + Math.floor(rng() * 4);
      for (let k = 0; k < len && cursor + k < n - 8; k++) {
        kinds[cursor + k] = "bridge";
        widths[cursor + k] = Math.max(5.1, level.width - 2.3);
      }
      cursor += len + 7;
    } else if (roll < level.bridge + level.mud) {
      for (let k = 0; k < 4 && cursor + k < n - 6; k++) kinds[cursor + k] = "mud";
      cursor += 8;
    } else if (roll < level.bridge + level.mud + level.broken) {
      for (let k = 0; k < 3 && cursor + k < n - 6; k++) {
        kinds[cursor + k] = "broken";
        widths[cursor + k] = Math.max(4.8, level.width - 1.6);
      }
      cursor += 8;
    } else if (rng() < 0.16) {
      kinds[cursor] = "narrow";
      widths[cursor] = Math.max(5.3, level.width - 1.7);
      if (cursor + 1 < n) {
        kinds[cursor + 1] = "narrow";
        widths[cursor + 1] = widths[cursor];
      }
      cursor += 6;
    } else {
      cursor += 1;
    }
  }

  const raw: { x: number; y: number; z: number; kind: SurfaceKind; width: number }[] = [];
  let x = 0;
  let z = 0;
  let heading = 0;
  for (let i = 0; i < n; i++) {
    const turn = (rng() - 0.5) * 2 * level.curve;
    heading = clamp(heading + turn, -1.02, 1.02);
    x += -Math.sin(heading) * 12;
    z += -Math.cos(heading) * 12;
    const t = i / (n - 1);
    const y = i * level.climb + Math.sin(i * 0.31) * (2.4 + level.curve * 10) + Math.sin(t * Math.PI) * 5;
    raw.push({ x, y, z, kind: kinds[i], width: widths[i] });
  }

  for (let pass = 0; pass < 2; pass++) {
    const ys = raw.map((p) => p.y);
    const ws = raw.map((p) => p.width);
    for (let i = 1; i < n - 1; i++) {
      ys[i] = (raw[i - 1].y + raw[i].y * 2 + raw[i + 1].y) / 4;
      if (raw[i].kind !== "bridge" && raw[i].kind !== "broken") {
        ws[i] = (raw[i - 1].width + raw[i].width * 2 + raw[i + 1].width) / 4;
      }
    }
    for (let i = 0; i < n; i++) {
      raw[i].y = ys[i];
      raw[i].width = ws[i];
    }
  }

  const track: TrackPoint[] = raw.map((p, i) => {
    const i0 = Math.max(0, i - 1);
    const i1 = Math.min(n - 1, i + 1);
    let tx = raw[i1].x - raw[i0].x;
    let tz = raw[i1].z - raw[i0].z;
    const len = Math.hypot(tx, tz) || 1;
    tx /= len;
    tz /= len;
    return {
      x: p.x,
      y: p.y,
      z: p.z,
      tx,
      tz,
      rx: -tz,
      rz: tx,
      width: p.width,
      kind: p.kind,
    };
  });

  let length = 0;
  for (let i = 0; i < n - 1; i++) {
    length += Math.hypot(track[i + 1].x - track[i].x, track[i + 1].z - track[i].z);
  }

  const obstacles: Obstacle[] = [];
  const palette: ObstacleKind[] = ["rock", "log", "block", "pit", "mud", "tree"];
  for (let i = 14; i < n - 8; i++) {
    if (rng() > level.obstacleRate) continue;
    const p = track[i];
    if (p.kind === "bridge") continue;
    const side = rng() < 0.5 ? -1 : 1;
    const off = side * (0.35 + rng() * p.width * 0.22);
    const kind = palette[Math.floor(rng() * palette.length)];
    const radius = kind === "pit" ? 1.65 : kind === "mud" ? 2.15 : kind === "log" ? 1.25 : kind === "block" ? 1.15 : 1.05;
    obstacles.push({
      kind,
      x: p.x + p.rx * off,
      y: p.y,
      z: p.z + p.rz * off,
      yaw: Math.atan2(-p.tx, -p.tz),
      radius,
      solid: kind === "rock" || kind === "log" || kind === "block" || kind === "tree",
    });
    if (obstacles.length >= 40) break;
  }

  const coins: CoinSpot[] = [];
  for (let i = 6; i < n - 4; i += 4) {
    const p = track[i];
    const side = (i / 4) % 2 === 0 ? -1.35 : 1.35;
    const cx = p.x + p.rx * side;
    const cz = p.z + p.rz * side;
    const blocked = obstacles.some((o) => (o.x - cx) ** 2 + (o.z - cz) ** 2 < 10);
    if (blocked) continue;
    coins.push({ x: cx, y: p.y + 1.15, z: cz });
  }

  return { track, length, obstacles, coins };
}

export function sampleTrack(track: TrackPoint[], x: number, z: number): TrackSample {
  const n = track.length;
  let best = Infinity;
  let bi = 0;
  let bt = 0;
  for (let i = 0; i < n - 1; i++) {
    const a = track[i];
    const b = track[i + 1];
    const abx = b.x - a.x;
    const abz = b.z - a.z;
    const ab2 = abx * abx + abz * abz;
    let t = ab2 > 1e-6 ? ((x - a.x) * abx + (z - a.z) * abz) / ab2 : 0;
    if (t < 0) t = 0;
    else if (t > 1) t = 1;
    const px = a.x + abx * t;
    const pz = a.z + abz * t;
    const d2 = (x - px) ** 2 + (z - pz) ** 2;
    if (d2 < best) {
      best = d2;
      bi = i;
      bt = t;
    }
  }
  const a = track[bi];
  const b = track[Math.min(n - 1, bi + 1)];
  const px = a.x + (b.x - a.x) * bt;
  const pz = a.z + (b.z - a.z) * bt;
  const py = a.y + (b.y - a.y) * bt;
  const tx = b.x - a.x;
  const tz = b.z - a.z;
  const horiz = Math.hypot(tx, tz) || 1;
  const tnx = tx / horiz;
  const tnz = tz / horiz;
  const rx = -tnz;
  const rz = tnx;
  const lateral = (x - px) * rx + (z - pz) * rz;
  return {
    x: px,
    y: py,
    z: pz,
    tx: tnx,
    tz: tnz,
    rx,
    rz,
    width: a.width + (b.width - a.width) * bt,
    kind: bt < 0.5 ? a.kind : b.kind,
    lateral,
    dist: Math.sqrt(best),
    grad: (b.y - a.y) / horiz,
    s: (bi + bt) / (n - 1),
    yaw: Math.atan2(-tnx, -tnz),
  };
}

export function pointAlong(track: TrackPoint[], s: number) {
  const n = track.length;
  const f = clamp(s, 0, 0.999) * (n - 1);
  const i = Math.floor(f);
  const t = f - i;
  const a = track[i];
  const b = track[Math.min(n - 1, i + 1)];
  return {
    x: a.x + (b.x - a.x) * t,
    y: a.y + (b.y - a.y) * t,
    z: a.z + (b.z - a.z) * t,
    tx: a.tx,
    tz: a.tz,
    rx: a.rx,
    rz: a.rz,
    yaw: Math.atan2(-a.tx, -a.tz),
  };
}
