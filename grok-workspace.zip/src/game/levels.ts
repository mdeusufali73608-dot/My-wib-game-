export type WeatherId = "sunrise" | "day" | "sunset" | "night" | "fog" | "storm";

export type LevelDef = {
  id: number;
  name: string;
  bn: string;
  weather: WeatherId;
  seed: number;
  segments: number;
  curve: number;
  climb: number;
  width: number;
  obstacleRate: number;
  bridge: number;
  mud: number;
  broken: number;
};

const PRESETS: { en: string; bn: string; weather: WeatherId }[] = [
  { en: "Green Valley", bn: "সবুজ উপত্যকা", weather: "sunrise" },
  { en: "Mountain Road", bn: "পাহাড়ি রাস্তা", weather: "day" },
  { en: "Dangerous Hill", bn: "বিপজ্জনক পাহাড়", weather: "fog" },
  { en: "Bridge Mountain", bn: "সেতুর পাহাড়", weather: "sunset" },
  { en: "Night Ridge", bn: "রাতের পাহাড়", weather: "night" },
  { en: "Extreme Mountain", bn: "চরম পাহাড়", weather: "storm" },
];

const SUFFIX = ["", " II", " III", " IV", " V"];

export const LEVEL_COUNT = 30;

export function getLevel(id: number): LevelDef {
  const i = Math.max(1, Math.min(LEVEL_COUNT, Math.round(id)));
  const preset = PRESETS[(i - 1) % PRESETS.length];
  const cycle = Math.floor((i - 1) / PRESETS.length);
  const suffix = SUFFIX[cycle] ?? ` ${cycle + 1}`;
  return {
    id: i,
    name: `${preset.en}${suffix}`,
    bn: `${preset.bn}${suffix}`,
    weather: preset.weather,
    seed: 1000 + i * 97,
    segments: 58 + i * 3,
    curve: 0.09 + i * 0.0055,
    climb: 0.16 + (i % 6) * 0.028,
    width: Math.max(6.3, 8.5 - i * 0.055),
    obstacleRate: Math.min(0.2, 0.055 + i * 0.0045),
    bridge: preset.weather === "sunset" ? 0.15 : 0.045 + cycle * 0.012,
    mud: 0.025 + i * 0.002,
    broken: i < 4 ? 0 : 0.018 + cycle * 0.008,
  };
}

export const WEATHER_LABEL: Record<WeatherId, string> = {
  sunrise: "সূর্যোদয়",
  day: "দিন",
  sunset: "সন্ধ্যা",
  night: "রাত",
  fog: "কুয়াশা",
  storm: "বৃষ্টি",
};
