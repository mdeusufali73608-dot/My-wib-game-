import * as THREE from "three";
import { RaceAudio } from "@/game/audio";
import { getCar, type CarDef } from "@/game/cars";
import { GameManager } from "@/game/game-manager";
import { getLevel, type LevelDef, type WeatherId } from "@/game/levels";
import { buildWorld, pointAlong, sampleTrack, type Obstacle, type TrackPoint, type TrackSample } from "@/game/track";

export type HeldAction = "left" | "right" | "throttle" | "brake" | "reverse" | "handbrake";

export type HudState = {
  speedKmh: number;
  time: number;
  progress: number;
  coinsRun: number;
  crashes: number;
  drift: number;
  wrongWay: boolean;
  nitroOn: boolean;
};

export type FinishResult = {
  level: number;
  time: number;
  crashes: number;
  coinsRun: number;
  stars: number;
  rewardText: string;
};

type Hooks = {
  onHud: (hud: HudState) => void;
  onFinish: (result: FinishResult) => void;
  onNotice: (text: string) => void;
  onBootError: (text: string) => void;
};

type Phase = "menu" | "race" | "pause" | "finish";

const WEATHER: Record<
  WeatherId,
  { sky: number; fog: number; hemi: number; ground: number; sun: number; amb: number; sunI: number; near: number; far: number }
> = {
  sunrise: { sky: 0xf2b183, fog: 0xe7c3a4, hemi: 0xffd0a8, ground: 0x3d5a3a, sun: 0xffb060, amb: 0.62, sunI: 1.35, near: 36, far: 150 },
  day: { sky: 0x8ec6ef, fog: 0xc5d8cc, hemi: 0xd7ecff, ground: 0x4a6b45, sun: 0xfff4dd, amb: 0.72, sunI: 1.45, near: 48, far: 190 },
  sunset: { sky: 0xe07a55, fog: 0xd9a08a, hemi: 0xffb199, ground: 0x3a3328, sun: 0xff7a45, amb: 0.5, sunI: 1.15, near: 30, far: 140 },
  night: { sky: 0x070b16, fog: 0x121826, hemi: 0x334466, ground: 0x0c1612, sun: 0x9eb6e8, amb: 0.42, sunI: 0.38, near: 24, far: 120 },
  fog: { sky: 0xc5cdd2, fog: 0xd5ddd8, hemi: 0xe7eeea, ground: 0x6a756c, sun: 0xffffff, amb: 0.62, sunI: 0.42, near: 14, far: 62 },
  storm: { sky: 0x1b2430, fog: 0x2a3442, hemi: 0x556677, ground: 0x141c18, sun: 0xb7c3d1, amb: 0.34, sunI: 0.4, near: 18, far: 90 },
};

const ROAD_COLOR: Record<TrackPoint["kind"], [number, number, number]> = {
  road: [0.23, 0.25, 0.27],
  bridge: [0.38, 0.34, 0.28],
  mud: [0.32, 0.22, 0.13],
  broken: [0.16, 0.15, 0.14],
  narrow: [0.26, 0.26, 0.28],
};

export class GameEngine {
  readonly canvas: HTMLCanvasElement;
  private renderer: THREE.WebGLRenderer | null = null;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(68, 1, 0.1, 500);
  private timer = new THREE.Timer();
  private audio = new RaceAudio();
  private world = new THREE.Group();
  private disposables: { dispose: () => void }[] = [];
  private hemi = new THREE.HemisphereLight(0xd7ecff, 0x4a6b45, 0.7);
  private sun = new THREE.DirectionalLight(0xfff4dd, 1.3);
  private carRoot = new THREE.Group();
  private wheels: THREE.Object3D[] = [];
  private frontPivots: THREE.Object3D[] = [];
  private shieldMesh: THREE.Object3D | null = null;
  private flame: THREE.Object3D | null = null;
  private spots: THREE.SpotLight[] = [];
  private rain: THREE.Points | null = null;
  private rainPositions: Float32Array | null = null;
  private coinMesh: THREE.InstancedMesh | null = null;
  private coinTaken: boolean[] = [];
  private coinBase: { x: number; y: number; z: number }[] = [];
  private obstacles: Obstacle[] = [];
  private track: TrackPoint[] = [];
  private length = 400;
  private level: LevelDef = getLevel(1);
  private car: CarDef = getCar("red");
  private sample: TrackSample | null = null;
  private dummy = new THREE.Object3D();
  private camPos = new THREE.Vector3(0, 8, 16);
  private look = new THREE.Vector3();
  private lookSmooth = new THREE.Vector3();
  private camReady = false;
  private minimap: HTMLCanvasElement | null = null;
  private minimapAcc = 0;
  private dead = false;
  private phase: Phase = "menu";
  private acc = 0;
  private hudAcc = 0;
  private previewS = 0.02;
  private keys = new Set<string>();
  private injected = new Set<string>();
  private held: Record<HeldAction, boolean> = {
    left: false,
    right: false,
    throttle: false,
    brake: false,
    reverse: false,
    handbrake: false,
  };
  private steerOverride: number | null = null;
  private useOverride = false;
  private tilt = 0;
  private x = 0;
  private y = 0;
  private z = 0;
  private yaw = 0;
  private speed = 0;
  private lat = 0;
  private steerVisual = 0;
  private wheelSpin = 0;
  private progress = 0;
  private time = 0;
  private crashes = 0;
  private coinsRun = 0;
  private drift = 0;
  private nitroTimer = 0;
  private invuln = 0;
  private shake = 0;
  private scrapeCd = 0;
  private finished = false;
  private wrongWay = false;
  private clock = 0;

  constructor(
    private host: HTMLElement,
    private hooks: Hooks,
  ) {
    this.canvas = document.createElement("canvas");
    this.canvas.style.position = "absolute";
    this.canvas.style.inset = "0";
    this.canvas.style.width = "100%";
    this.canvas.style.height = "100%";
    this.canvas.style.display = "block";
    this.canvas.style.pointerEvents = "none";
    this.host.appendChild(this.canvas);
    this.scene.add(this.world);
    this.scene.add(this.carRoot);
    this.scene.add(this.hemi);
    this.sun.position.set(30, 40, 12);
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
    this.scene.fog = new THREE.Fog(0xc5d8cc, 40, 180);

    try {
      this.renderer = new THREE.WebGLRenderer({
        canvas: this.canvas,
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
      });
    } catch {
      this.hooks.onBootError("এই ডিভাইসে 3D চালু হয়নি।");
      return;
    }
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
    this.timer.connect(document);
    this.resize();
    this.bindInput();
    window.__controlsTest = {
      getYaw: () => this.yaw,
      getSpeed: () => this.speed,
      setKeys: (codes: string[]) => {
        this.injected = new Set(codes);
      },
      setSteer: (v: number) => {
        this.steerOverride = Math.max(-1, Math.min(1, v));
        this.useOverride = true;
      },
    };
    this.boot();
    this.renderer.setAnimationLoop(this.frame);
  }

  private boot() {
    const gm = GameManager.Instance;
    this.car = getCar(gm.selectedCar);
    this.loadLevel(gm.selectedLevel);
    this.audio.setFlags(gm.isSoundOn, gm.isMusicOn);
  }

  dispose() {
    this.dead = true;
    this.renderer?.setAnimationLoop(null);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    document.removeEventListener("visibilitychange", this.onVis);
    window.removeEventListener("deviceorientation", this.onOrient);
    window.removeEventListener("pointerdown", this.onPointer);
    window.removeEventListener("resize", this.resize);
    this.clearWorld();
    this.renderer?.dispose();
    this.canvas.remove();
    if (window.__controlsTest?.getYaw === this.yawReader) {
      delete window.__controlsTest;
    }
  }

  private yawReader = () => this.yaw;

  setMinimap(canvas: HTMLCanvasElement | null) {
    this.minimap = canvas;
  }

  setHeld(action: HeldAction, down: boolean) {
    this.held[action] = down;
  }

  previewLevel(id: number) {
    if (this.phase === "race") return;
    const gm = GameManager.Instance;
    gm.selectedLevel = id;
    gm.SaveGameData();
    this.loadLevel(id);
    this.phase = "menu";
  }

  setCar(id: string) {
    const gm = GameManager.Instance;
    gm.selectedCar = id;
    gm.SaveGameData();
    this.car = getCar(id);
    this.rebuildCar();
    this.placeCarAtStart(false);
  }

  applyAudio() {
    const gm = GameManager.Instance;
    this.audio.setFlags(gm.isSoundOn, gm.isMusicOn);
  }

  startRace() {
    const gm = GameManager.Instance;
    this.audio.unlock();
    if (this.level.id !== gm.selectedLevel || this.car.id !== gm.selectedCar) {
      this.car = getCar(gm.selectedCar);
      this.loadLevel(gm.selectedLevel);
    }
    this.placeCarAtStart(true);
    this.time = 0;
    this.crashes = 0;
    this.coinsRun = 0;
    this.drift = 0;
    this.nitroTimer = 0;
    this.invuln = 0.4;
    this.shake = 0;
    this.finished = false;
    this.wrongWay = false;
    this.coinTaken.fill(false);
    this.phase = "race";
    this.camReady = false;
    this.pushHud();
  }

  pause() {
    if (this.phase === "race") this.phase = "pause";
  }

  resume() {
    if (this.phase === "pause") this.phase = "race";
  }

  toMenu() {
    this.phase = "menu";
    this.speed = 0;
    this.camReady = false;
  }

  activateNitro() {
    if (this.phase !== "race" || this.nitroTimer > 0) return;
    const gm = GameManager.Instance;
    if (!gm.UseNitro()) {
      if (gm.isNotificationOn) this.hooks.onNotice("নাইট্রো শেষ");
      return;
    }
    this.nitroTimer = 2.4;
    this.audio.nitro();
    if (gm.isNotificationOn) this.hooks.onNotice("টার্বো নাইট্রো!");
  }

  rescue() {
    if (this.phase !== "race" && this.phase !== "pause") return;
    this.respawn(false);
  }

  private bindInput() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    document.addEventListener("visibilitychange", this.onVis);
    window.addEventListener("deviceorientation", this.onOrient);
    window.addEventListener("pointerdown", this.onPointer);
    window.addEventListener("resize", this.resize);
  }

  private onPointer = () => this.audio.unlock();

  private onKeyDown = (event: KeyboardEvent) => {
    this.keys.add(event.code);
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(event.code)) event.preventDefault();
    if ((event.code === "KeyN" || event.code === "ShiftLeft" || event.code === "ShiftRight") && !event.repeat) {
      this.activateNitro();
    }
  };

  private onKeyUp = (event: KeyboardEvent) => {
    this.keys.delete(event.code);
  };

  private onBlur = () => {
    this.keys.clear();
    (Object.keys(this.held) as HeldAction[]).forEach((key) => {
      this.held[key] = false;
    });
  };

  private onVis = () => {
    if (document.visibilityState === "visible") this.audio.resume();
    else this.onBlur();
  };

  private onOrient = (event: DeviceOrientationEvent) => {
    const gamma = event.gamma ?? 0;
    this.tilt = Math.max(-1, Math.min(1, -gamma / 26));
  };

  private resize = () => {
    if (!this.renderer) return;
    const w = this.host.clientWidth || 1;
    const h = this.host.clientHeight || 1;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
  };

  private frame = (stamp?: number) => {
    if (this.dead || !this.renderer) return;
    this.timer.update(stamp);
    const frameDt = Math.min(this.timer.getDelta(), 0.05);
    this.clock += frameDt;
    this.acc += frameDt;
    if (this.acc > 0.12) this.acc = 0.12;
    const step = 1 / 60;
    let guard = 0;
    while (this.acc >= step && guard < 4) {
      this.simulate(step);
      this.acc -= step;
      guard += 1;
    }
    this.animateWorld(frameDt);
    this.updateCamera(frameDt);
    this.audio.updateEngine(this.speed, this.phase === "race" && this.input().throttle ? 1 : 0, this.phase === "race");
    this.audio.updateMusic(frameDt, true);
    this.hudAcc += frameDt;
    if (this.hudAcc > 0.1) {
      this.hudAcc = 0;
      this.pushHud();
    }
    this.minimapAcc += frameDt;
    if (this.minimapAcc > 0.12) {
      this.minimapAcc = 0;
      this.drawMinimap();
    }
    this.renderer.render(this.scene, this.camera);
  };

  private input() {
    const down = (code: string) => this.keys.has(code) || this.injected.has(code);
    let steer = 0;
    if (this.held.left || down("KeyA") || down("ArrowLeft")) steer += 1;
    if (this.held.right || down("KeyD") || down("ArrowRight")) steer -= 1;
    const gm = GameManager.Instance;
    if (gm.useTiltSteering) steer += this.tilt;
    steer *= gm.steeringSensitivity;
    if (this.useOverride && this.steerOverride !== null) steer = this.steerOverride;
    steer = Math.max(-1, Math.min(1, steer));
    return {
      throttle: this.held.throttle || down("KeyW") || down("ArrowUp") ? 1 : 0,
      brake: this.held.brake || down("KeyS") || down("ArrowDown") ? 1 : 0,
      reverse: this.held.reverse || down("KeyR") ? 1 : 0,
      hand: this.held.handbrake || down("Space") ? 1 : 0,
      steer,
    };
  }

  private simulate(dt: number) {
    if (this.invuln > 0) this.invuln -= dt;
    if (this.scrapeCd > 0) this.scrapeCd -= dt;
    if (this.nitroTimer > 0) this.nitroTimer -= dt;
    if (this.phase !== "race") return;

    const input = this.input();
    const car = this.car;
    if (input.brake) this.speed -= car.brake * dt;
    else if (input.reverse) this.speed -= car.accel * 0.5 * dt;
    else if (input.throttle) this.speed += car.accel * dt;
    if (this.nitroTimer > 0) this.speed += car.accel * 1.35 * dt;

    const off = this.sample ? this.sample.dist > this.sample.width * 0.5 + 0.4 : false;
    const mud = this.sample?.kind === "mud";
    let drag = input.throttle > 0 || input.reverse > 0 ? 0.16 : 0.42;
    if (off) drag += 1.15;
    if (mud) drag += 1.35;
    this.speed -= this.speed * drag * dt;
    const cap = car.maxSpeed * (this.nitroTimer > 0 ? 1.28 : 1);
    this.speed = Math.max(-car.maxSpeed * 0.34, Math.min(cap, this.speed));

    const speedFactor = Math.max(0.22, Math.min(1, Math.abs(this.speed) / 12));
    const reverse = this.speed >= 0 ? 1 : -1;
    const hand = input.hand > 0;
    this.yaw += input.steer * car.turn * speedFactor * reverse * (hand ? 1.35 : 1) * dt;

    const slip = Math.abs(input.steer) * Math.abs(this.speed) * (hand ? 2.1 : 0.18);
    this.lat += input.steer * slip * dt;
    const grip = car.grip * (hand ? 0.28 : 1) * (mud ? 0.5 : 1);
    this.lat *= Math.exp(-grip * 5.5 * dt);
    this.lat = Math.max(-14, Math.min(14, this.lat));

    if (hand && Math.abs(input.steer) > 0.35 && Math.abs(this.speed) > 9) this.drift = Math.min(1, this.drift + dt * 0.5);
    else if (!hand && this.drift > 0.4) {
      this.speed = Math.min(cap, this.speed + 7 + this.drift * 12);
      this.drift = 0;
      this.audio.nitro();
    } else this.drift = Math.max(0, this.drift - dt * 0.55);

    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw);
    const rz = -Math.sin(this.yaw);
    this.x += (fx * this.speed + rx * this.lat) * dt;
    this.z += (fz * this.speed + rz * this.lat) * dt;

    let sm = sampleTrack(this.track, this.x, this.z);
    if (sm.kind !== "broken") {
      const limit = sm.width * 0.5 - 0.75;
      if (Math.abs(sm.lateral) > limit) {
        const sign = Math.sign(sm.lateral) || 1;
        const push = Math.abs(sm.lateral) - limit;
        this.x -= sm.rx * sign * push;
        this.z -= sm.rz * sign * push;
        this.lat *= -0.15;
        if (push > 0.25 && Math.abs(this.speed) > 11 && this.scrapeCd <= 0) {
          this.speed *= 0.94;
          this.scrapeCd = 0.35;
          this.audio.scrape();
          this.shake = Math.max(this.shake, 0.12);
        }
        sm = sampleTrack(this.track, this.x, this.z);
      }
    }
    const fell =
      sm.dist > sm.width * 0.5 + 8 ||
      (sm.kind === "broken" && Math.abs(sm.lateral) > sm.width * 0.5 + 1.25) ||
      (sm.kind === "bridge" && Math.abs(sm.lateral) > sm.width * 0.5 + 0.85);
    if (fell) {
      this.respawn(true);
      sm = sampleTrack(this.track, this.x, this.z);
    }

    this.resolveObstacles(sm);
    sm = sampleTrack(this.track, this.x, this.z);
    this.sample = sm;
    this.y = sm.y;
    this.collectCoins();

    if (sm.dist < sm.width && sm.s > this.progress && sm.s - this.progress < 0.06) this.progress = sm.s;
    const align = fx * sm.tx + fz * sm.tz;
    this.wrongWay = align < -0.35 && this.speed > 5;
    this.time += dt;
    this.steerVisual += (input.steer - this.steerVisual) * Math.min(1, dt * 10);
    if (this.progress >= 0.988) this.finishRace();
  }

  private resolveObstacles(sm: TrackSample) {
    let slow = sm.kind === "mud" ? 1.2 : 0;
    for (const obstacle of this.obstacles) {
      const dx = this.x - obstacle.x;
      const dz = this.z - obstacle.z;
      const dist = Math.hypot(dx, dz) || 0.0001;
      const reach = obstacle.radius + (obstacle.solid ? 0.85 : 0);
      if (dist > reach) continue;
      if (!obstacle.solid) {
        slow += obstacle.kind === "pit" ? 2.5 : 1.2;
        continue;
      }
      if (this.invuln <= 0) {
        const gm = GameManager.Instance;
        if (gm.shieldCount > 0) {
          gm.UseShield();
          this.invuln = 1.15;
          this.audio.shield();
          this.shake = Math.max(this.shake, 0.2);
          if (gm.isNotificationOn) this.hooks.onNotice("শিল্ড পাথর আটকালো");
        } else {
          this.crashes += 1;
          this.speed *= 0.42;
          this.invuln = 0.8;
          this.shake = 0.5;
          this.audio.crash();
        }
      }
      const overlap = reach - dist;
      this.x += (dx / dist) * overlap;
      this.z += (dz / dist) * overlap;
      this.lat += Math.sign(dx * sm.rx + dz * sm.rz) * 3;
    }
    if (slow > 0) this.speed -= this.speed * slow * (1 / 60);
  }

  private collectCoins() {
    for (let i = 0; i < this.coinBase.length; i++) {
      if (this.coinTaken[i]) continue;
      const coin = this.coinBase[i];
      const d = (coin.x - this.x) ** 2 + (coin.z - this.z) ** 2;
      if (d > 2.4) continue;
      this.coinTaken[i] = true;
      this.coinsRun += 1;
      GameManager.Instance.AddCoins(5);
      this.audio.coin();
    }
  }

  private respawn(countCrash: boolean) {
    const p = pointAlong(this.track, Math.max(0.015, this.progress - 0.01));
    this.x = p.x;
    this.z = p.z;
    this.y = p.y;
    this.yaw = p.yaw;
    this.speed = 7;
    this.lat = 0;
    this.invuln = 1.1;
    this.shake = Math.max(this.shake, 0.25);
    if (countCrash) this.crashes += 1;
  }

  private finishRace() {
    if (this.finished) return;
    this.finished = true;
    this.phase = "finish";
    this.speed = 0;
    const gm = GameManager.Instance;
    const stars = this.starCount();
    const key = String(this.level.id);
    const prev = gm.best[key];
    if (!prev || this.time < prev.time) gm.best[key] = { time: this.time, stars: Math.max(stars, prev?.stars ?? 0) };
    else if (stars > prev.stars) gm.best[key] = { time: prev.time, stars };
    gm.unlockedLevel = Math.max(gm.unlockedLevel, Math.min(30, this.level.id + 1));
    const rewardText = gm.GrantLevelWinReward(this.level.id);
    this.hooks.onFinish({
      level: this.level.id,
      time: this.time,
      crashes: this.crashes,
      coinsRun: this.coinsRun,
      stars,
      rewardText,
    });
    this.pushHud();
  }

  private starCount() {
    const par = this.length / 17;
    if (this.time < par && this.crashes <= 1) return 3;
    if (this.time < par * 1.4 && this.crashes <= 4) return 2;
    return 1;
  }

  private pushHud() {
    this.hooks.onHud({
      speedKmh: Math.round(Math.abs(this.speed) * 3.6),
      time: this.time,
      progress: this.progress,
      coinsRun: this.coinsRun,
      crashes: this.crashes,
      drift: this.drift,
      wrongWay: this.wrongWay,
      nitroOn: this.nitroTimer > 0,
    });
  }

  private loadLevel(id: number) {
    this.level = getLevel(id);
    const built = buildWorld(this.level);
    this.track = built.track;
    this.length = built.length;
    this.obstacles = built.obstacles;
    this.clearWorld();
    this.scene.add(this.world);
    this.buildScenery(built.coins);
    this.rebuildCar();
    this.placeCarAtStart(false);
    this.progress = 0.02;
    this.previewS = 0.012;
    this.camReady = false;
    this.applySky();
  }

  private applySky() {
    const gm = GameManager.Instance;
    const id: WeatherId = gm.weather === "auto" ? this.level.weather : gm.weather;
    const w = WEATHER[id];
    this.scene.background = new THREE.Color(w.sky);
    this.scene.fog = new THREE.Fog(w.fog, w.near, w.far);
    this.hemi.color.setHex(w.hemi);
    this.hemi.groundColor.setHex(w.ground);
    this.hemi.intensity = w.amb;
    this.sun.color.setHex(w.sun);
    this.sun.intensity = w.sunI;
    const night = id === "night" || id === "storm";
    for (const spot of this.spots) spot.intensity = night ? 7 : id === "sunset" || id === "fog" ? 2.2 : 0;
    if (this.rain) this.rain.visible = id === "storm";
  }

  refreshWeather() {
    this.applySky();
  }

  private clearWorld() {
    if (this.rain) {
      this.scene.remove(this.rain);
      this.rain = null;
      this.rainPositions = null;
    }
    this.world.clear();
    for (const item of this.disposables) item.dispose();
    this.disposables = [];
    this.coinMesh = null;
  }

  private trackDisposable<T extends { dispose: () => void }>(resource: T): T {
    this.disposables.push(resource);
    return resource;
  }

  private buildScenery(coins: { x: number; y: number; z: number }[]) {
    const pts = this.track;
    const road = this.ribbon(pts, (p) => p.width * 0.5, 0.02, (p) => ROAD_COLOR[p.kind], () => false);
    const shoulder = this.ribbon(
      pts,
      (p) => p.width * 0.5 + 2.4,
      -0.05,
      () => [0.13, 0.3, 0.16],
      (p) => p.kind === "bridge" || p.kind === "broken",
    );
    const paint = this.ribbon(
      pts,
      () => 0.09,
      0.06,
      () => [0.78, 0.68, 0.32],
      (p) => p.kind === "broken",
    );
    const roadMat = this.trackDisposable(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, metalness: 0.04, side: THREE.DoubleSide }));
    const grassMat = this.trackDisposable(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0, side: THREE.DoubleSide }));
    const paintMat = this.trackDisposable(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.5, metalness: 0.1, side: THREE.DoubleSide }));
    this.world.add(new THREE.Mesh(road, roadMat), new THREE.Mesh(shoulder, grassMat), new THREE.Mesh(paint, paintMat));

    let minY = Infinity;
    let cx = 0;
    let cz = 0;
    for (const p of pts) {
      minY = Math.min(minY, p.y);
      cx += p.x;
      cz += p.z;
    }
    cx /= pts.length;
    cz /= pts.length;

    const groundGeo = this.trackDisposable(new THREE.CircleGeometry(520, 40));
    groundGeo.rotateX(-Math.PI / 2);
    const ground = new THREE.Mesh(groundGeo, this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x0c1c14, roughness: 1 })));
    ground.position.set(cx, minY - 22, cz);
    const waterGeo = this.trackDisposable(new THREE.CircleGeometry(240, 32));
    waterGeo.rotateX(-Math.PI / 2);
    const water = new THREE.Mesh(
      waterGeo,
      this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x16485c, roughness: 0.18, metalness: 0.35, transparent: true, opacity: 0.92 })),
    );
    water.position.set(cx, minY - 8, cz);
    this.world.add(ground, water);

    const coneGeo = this.trackDisposable(new THREE.ConeGeometry(22, 78, 6));
    const rockMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x2a3330, roughness: 0.95 }));
    const mossMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x1b3a28, roughness: 1 }));
    for (let i = 0; i < 18; i++) {
      const angle = (i / 18) * Math.PI * 2;
      const radius = 150 + (i % 3) * 28;
      const mesh = new THREE.Mesh(coneGeo, i % 2 === 0 ? mossMat : rockMat);
      const h = 70 + (i % 5) * 18;
      mesh.scale.set(1, h / 78, 1);
      mesh.position.set(cx + Math.cos(angle) * radius, minY - 18 + h * 0.35, cz + Math.sin(angle) * radius);
      this.world.add(mesh);
    }

    this.addForest(pts);
    this.addRails(pts);
    this.addObstacles();
    this.addCoins(coins);
    this.addDressing(pts, minY);
    this.addRain();
  }

  private ribbon(
    pts: TrackPoint[],
    half: (p: TrackPoint) => number,
    lift: number,
    color: (p: TrackPoint) => [number, number, number],
    skip: (p: TrackPoint) => boolean,
  ) {
    const positions: number[] = [];
    const colors: number[] = [];
    const indices: number[] = [];
    for (const p of pts) {
      const hw = half(p);
      const c = color(p);
      positions.push(p.x + p.rx * hw, p.y + lift, p.z + p.rz * hw, p.x - p.rx * hw, p.y + lift, p.z - p.rz * hw);
      colors.push(c[0], c[1], c[2], c[0], c[1], c[2]);
    }
    for (let i = 0; i < pts.length - 1; i++) {
      if (skip(pts[i])) continue;
      const a = i * 2;
      indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
    const geo = this.trackDisposable(new THREE.BufferGeometry());
    geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    return geo;
  }

  private addForest(pts: TrackPoint[]) {
    let count = 0;
    for (let i = 2; i < pts.length; i += 2) {
      if (pts[i].kind === "bridge" || pts[i].kind === "broken") continue;
      count += 2;
    }
    const trunkGeo = this.trackDisposable(new THREE.CylinderGeometry(0.18, 0.26, 1.6, 5));
    const leafGeo = this.trackDisposable(new THREE.ConeGeometry(1.15, 2.8, 6));
    const trunkMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x5a3b28, roughness: 1 }));
    const leafMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x1f6b3a, roughness: 0.9 }));
    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, Math.max(1, count));
    const leaves = new THREE.InstancedMesh(leafGeo, leafMat, Math.max(1, count));
    let n = 0;
    for (let i = 2; i < pts.length; i += 2) {
      const p = pts[i];
      if (p.kind === "bridge" || p.kind === "broken") continue;
      for (const side of [-1, 1]) {
        const dist = p.width * 0.5 + 3.2 + ((i * side) % 5);
        const jitter = ((i * 17) % 7) * 0.35;
        this.dummy.position.set(p.x + p.rx * side * dist, p.y + 0.8, p.z + p.rz * side * dist + jitter);
        this.dummy.scale.set(1, 0.8 + (i % 4) * 0.18, 1);
        this.dummy.rotation.set(0, i, 0);
        this.dummy.updateMatrix();
        trunks.setMatrixAt(n, this.dummy.matrix);
        this.dummy.position.y = p.y + 2.5 + (i % 3) * 0.2;
        this.dummy.scale.set(0.85 + (i % 3) * 0.15, 0.9 + (i % 4) * 0.12, 0.85);
        this.dummy.updateMatrix();
        leaves.setMatrixAt(n, this.dummy.matrix);
        n += 1;
      }
    }
    trunks.count = n;
    leaves.count = n;
    trunks.instanceMatrix.needsUpdate = true;
    leaves.instanceMatrix.needsUpdate = true;
    this.world.add(trunks, leaves);
  }

  private addRails(pts: TrackPoint[]) {
    const geo = this.trackDisposable(new THREE.BoxGeometry(1, 1, 1));
    const mat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0xc9b48a, roughness: 0.6, metalness: 0.25 }));
    const mesh = new THREE.InstancedMesh(geo, mat, pts.length * 2);
    let n = 0;
    for (let i = 0; i < pts.length - 1; i++) {
      const p = pts[i];
      if (p.kind === "broken") continue;
      const len = Math.hypot(pts[i + 1].x - p.x, pts[i + 1].z - p.z);
      for (const side of [-1, 1]) {
        const edge = p.width * 0.5 - 0.15;
        this.dummy.position.set(p.x + p.rx * side * edge, p.y + 0.38, p.z + p.rz * side * edge);
        this.dummy.lookAt(this.dummy.position.x + p.tx, this.dummy.position.y, this.dummy.position.z + p.tz);
        this.dummy.scale.set(0.16, p.kind === "bridge" ? 0.7 : 0.42, len);
        this.dummy.updateMatrix();
        mesh.setMatrixAt(n, this.dummy.matrix);
        n += 1;
      }
    }
    mesh.count = n;
    mesh.instanceMatrix.needsUpdate = true;
    this.world.add(mesh);
  }

  private addObstacles() {
    const rockGeo = this.trackDisposable(new THREE.DodecahedronGeometry(0.85, 0));
    const rockMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x6d655c, roughness: 0.95 }));
    const logGeo = this.trackDisposable(new THREE.CylinderGeometry(0.32, 0.38, 2.6, 7));
    logGeo.rotateZ(Math.PI / 2);
    const logMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x6a442c, roughness: 1 }));
    const blockMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0xd7a441, roughness: 0.7 }));
    const darkMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.8 }));
    const pitGeo = this.trackDisposable(new THREE.CircleGeometry(1.55, 16));
    pitGeo.rotateX(-Math.PI / 2);
    const pitMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x10110f, roughness: 1 }));
    const mudGeo = this.trackDisposable(new THREE.CircleGeometry(2.05, 18));
    mudGeo.rotateX(-Math.PI / 2);
    const mudMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x5a3d22, roughness: 1 }));
    const trunkGeo = this.trackDisposable(new THREE.CylinderGeometry(0.22, 0.3, 1.8, 6));
    const leafGeo = this.trackDisposable(new THREE.ConeGeometry(1, 2.2, 6));
    const leafMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0x2d7a40, roughness: 0.9 }));

    for (const obstacle of this.obstacles) {
      if (obstacle.kind === "rock") {
        const mesh = new THREE.Mesh(rockGeo, rockMat);
        mesh.position.set(obstacle.x, obstacle.y + 0.55, obstacle.z);
        mesh.scale.set(1, 0.75 + (obstacle.x % 1) * 0.2, 1);
        this.world.add(mesh);
      } else if (obstacle.kind === "log") {
        const mesh = new THREE.Mesh(logGeo, logMat);
        mesh.position.set(obstacle.x, obstacle.y + 0.38, obstacle.z);
        mesh.lookAt(obstacle.x + Math.sin(obstacle.yaw), obstacle.y + 0.38, obstacle.z + Math.cos(obstacle.yaw));
        this.world.add(mesh);
      } else if (obstacle.kind === "block") {
        const group = new THREE.Group();
        const a = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.7, 0.45), blockMat);
        const b = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.7, 0.45), darkMat);
        a.position.set(0, 0.4, -0.28);
        b.position.set(0, 0.4, 0.28);
        group.add(a, b);
        group.position.set(obstacle.x, obstacle.y, obstacle.z);
        group.lookAt(obstacle.x + Math.sin(obstacle.yaw), obstacle.y, obstacle.z + Math.cos(obstacle.yaw));
        this.world.add(group);
        this.trackDisposable(a.geometry);
        this.trackDisposable(b.geometry);
      } else if (obstacle.kind === "pit") {
        const mesh = new THREE.Mesh(pitGeo, pitMat);
        mesh.position.set(obstacle.x, obstacle.y + 0.07, obstacle.z);
        this.world.add(mesh);
      } else if (obstacle.kind === "mud") {
        const mesh = new THREE.Mesh(mudGeo, mudMat);
        mesh.position.set(obstacle.x, obstacle.y + 0.05, obstacle.z);
        this.world.add(mesh);
      } else {
        const trunk = new THREE.Mesh(trunkGeo, logMat);
        const leaf = new THREE.Mesh(leafGeo, leafMat);
        trunk.position.set(obstacle.x, obstacle.y + 0.7, obstacle.z);
        trunk.rotation.z = 1.15;
        leaf.position.set(obstacle.x + 0.7, obstacle.y + 0.45, obstacle.z);
        this.world.add(trunk, leaf);
      }
    }
  }

  private addCoins(coins: { x: number; y: number; z: number }[]) {
    this.coinBase = coins;
    this.coinTaken = coins.map(() => false);
    const geo = this.trackDisposable(new THREE.OctahedronGeometry(0.32, 0));
    const mat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0xe4b15a, metalness: 0.7, roughness: 0.25, emissive: 0x6a4a12, emissiveIntensity: 0.4 }));
    const mesh = new THREE.InstancedMesh(geo, mat, Math.max(1, coins.length));
    mesh.count = coins.length;
    this.coinMesh = mesh;
    this.world.add(mesh);
    this.syncCoins(0);
  }

  private syncCoins(time: number) {
    if (!this.coinMesh) return;
    for (let i = 0; i < this.coinBase.length; i++) {
      const coin = this.coinBase[i];
      const taken = this.coinTaken[i];
      this.dummy.position.set(coin.x, coin.y + Math.sin(time * 3 + i) * 0.12, coin.z);
      this.dummy.rotation.set(0, time * 1.6 + i, 0);
      this.dummy.scale.setScalar(taken ? 0.001 : 1);
      this.dummy.updateMatrix();
      this.coinMesh.setMatrixAt(i, this.dummy.matrix);
    }
    this.coinMesh.instanceMatrix.needsUpdate = true;
  }

  private addDressing(pts: TrackPoint[], minY: number) {
    const fallMat = this.trackDisposable(
      new THREE.MeshStandardMaterial({ color: 0xe7f6ff, transparent: true, opacity: 0.45, roughness: 0.15, depthWrite: false }),
    );
    const fallGeo = this.trackDisposable(new THREE.PlaneGeometry(2.2, 7));
    let falls = 0;
    for (let i = 8; i < pts.length && falls < 3; i += Math.floor(pts.length / 4)) {
      const p = pts[i];
      if (p.kind === "bridge") continue;
      const mesh = new THREE.Mesh(fallGeo, fallMat);
      mesh.position.set(p.x + p.rx * (p.width * 0.5 + 5), p.y + 2.2, p.z + p.rz * (p.width * 0.5 + 5));
      mesh.lookAt(p.x, p.y + 2, p.z);
      this.world.add(mesh);
      falls += 1;
    }
    const cloudGeo = this.trackDisposable(new THREE.SphereGeometry(7, 8, 6));
    const cloudMat = this.trackDisposable(new THREE.MeshStandardMaterial({ color: 0xf7f4ee, transparent: true, opacity: 0.55, depthWrite: false }));
    for (let i = 0; i < 7; i++) {
      const p = pts[Math.floor((i / 7) * (pts.length - 1))];
      const mesh = new THREE.Mesh(cloudGeo, cloudMat);
      mesh.scale.set(1.4, 0.38, 1);
      mesh.position.set(p.x + p.rx * (18 + i * 3), Math.max(p.y + 16, minY + 28), p.z + 6);
      mesh.name = "cloud";
      this.world.add(mesh);
    }
  }

  private addRain() {
    const count = 700;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 40;
      positions[i * 3 + 1] = Math.random() * 22;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 40;
    }
    const geo = this.trackDisposable(new THREE.BufferGeometry());
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const mat = this.trackDisposable(new THREE.PointsMaterial({ color: 0xd5e4ee, size: 0.08, transparent: true, opacity: 0.65 }));
    this.rain = new THREE.Points(geo, mat);
    this.rain.visible = false;
    this.rainPositions = positions;
    this.scene.add(this.rain);
  }

  private rebuildCar() {
    const dumped = new Set<THREE.BufferGeometry | THREE.Material>();
    this.carRoot.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (!mesh.isMesh) return;
      if (mesh.geometry && !dumped.has(mesh.geometry)) {
        dumped.add(mesh.geometry);
        mesh.geometry.dispose();
      }
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const mat of mats) {
        if (mat && !dumped.has(mat)) {
          dumped.add(mat);
          mat.dispose();
        }
      }
    });
    this.carRoot.clear();
    this.wheels = [];
    this.frontPivots = [];
    this.spots = [];
    const color = new THREE.Color(this.car.color);
    const paint = new THREE.MeshStandardMaterial({ color, metalness: 0.58, roughness: 0.32 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x141414, roughness: 0.72, metalness: 0.25 });
    const glass = new THREE.MeshStandardMaterial({ color: 0xb9e6ff, roughness: 0.05, metalness: 0.15, transparent: true, opacity: 0.55 });
    const gold = new THREE.MeshStandardMaterial({ color: 0xe4b15a, metalness: 0.6, roughness: 0.3 });
    const lamp = new THREE.MeshStandardMaterial({ color: 0xfff1cc, emissive: 0xffcc77, emissiveIntensity: 1.5 });
    const tail = new THREE.MeshStandardMaterial({ color: 0xff2a2a, emissive: 0xaa1111, emissiveIntensity: 1.1 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.72, 0.38, 4.05), paint);
    body.position.set(0, 0.5, 0);
    const skirt = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.12, 4.12), dark);
    skirt.position.set(0, 0.28, 0);
    const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.42, 0.4, 1.65), glass);
    cabin.position.set(0, 0.84, -0.32);
    const hood = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.1, 1.25), paint);
    hood.position.set(0, 0.7, 1.05);
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.05, 3.1), gold);
    stripe.position.set(0, 0.72, 0.15);
    const nose = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.16, 0.2), dark);
    nose.position.set(0, 0.42, 2.02);
    this.carRoot.add(body, skirt, cabin, hood, stripe, nose);

    const wheelGeo = new THREE.CylinderGeometry(0.34, 0.34, 0.26, 14);
    wheelGeo.rotateZ(Math.PI / 2);
    const spots: [number, number, boolean][] = [
      [-0.82, 1.28, true],
      [0.82, 1.28, true],
      [-0.82, -1.28, false],
      [0.82, -1.28, false],
    ];
    for (const [wx, wz, front] of spots) {
      const pivot = new THREE.Group();
      pivot.position.set(wx, 0.34, wz);
      const wheel = new THREE.Mesh(wheelGeo, dark);
      pivot.add(wheel);
      this.carRoot.add(pivot);
      this.wheels.push(wheel);
      if (front) this.frontPivots.push(pivot);
    }
    const lampGeo = new THREE.BoxGeometry(0.24, 0.12, 0.08);
    for (const side of [-0.52, 0.52]) {
      const hl = new THREE.Mesh(lampGeo, lamp);
      hl.position.set(side, 0.55, 2.04);
      const tl = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.1, 0.06), tail);
      tl.position.set(side, 0.58, -2.02);
      this.carRoot.add(hl, tl);
    }
    const flameGeo = new THREE.ConeGeometry(0.28, 1.1, 8);
    flameGeo.rotateX(-Math.PI / 2);
    this.flame = new THREE.Mesh(flameGeo, new THREE.MeshStandardMaterial({ color: 0xff8a3d, emissive: 0xff5a1f, emissiveIntensity: 2 }));
    this.flame.position.set(0, 0.42, -2.35);
    this.flame.visible = false;
    this.carRoot.add(this.flame);

    const shield = new THREE.Mesh(
      new THREE.SphereGeometry(2.25, 18, 12),
      new THREE.MeshStandardMaterial({ color: 0x8ee7ff, transparent: true, opacity: 0.16, roughness: 0.05, depthWrite: false }),
    );
    shield.position.y = 0.7;
    shield.visible = false;
    this.shieldMesh = shield;
    this.carRoot.add(shield);

    for (const side of [-0.4, 0.4]) {
      const spot = new THREE.SpotLight(0xfff1cc, 0, 34, 0.55, 0.5, 1.1);
      spot.position.set(side, 0.6, 1.7);
      const target = new THREE.Object3D();
      target.position.set(side, 0.25, 14);
      this.carRoot.add(spot, target);
      spot.target = target;
      this.spots.push(spot);
    }
    this.applySky();
  }

  private placeCarAtStart(boost: boolean) {
    const p = this.track[Math.min(5, this.track.length - 1)];
    if (!p) return;
    this.x = p.x;
    this.y = p.y;
    this.z = p.z;
    this.yaw = Math.atan2(-p.tx, -p.tz);
    this.speed = boost ? 0 : 0;
    this.lat = 0;
    this.progress = 5 / Math.max(1, this.track.length - 1);
    this.sample = sampleTrack(this.track, this.x, this.z);
    this.steerVisual = 0;
  }

  private animateWorld(dt: number) {
    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const sm = this.sample;
    const grad = sm ? sm.grad * (fx * sm.tx + fz * sm.tz) : 0;
    this.carRoot.position.set(this.x, this.y, this.z);
    this.carRoot.lookAt(this.x + fx * 8, this.y + grad * 8, this.z + fz * 8);
    this.carRoot.rotateZ(-this.steerVisual * 0.12);
    this.wheelSpin -= this.speed * dt * 2.6;
    for (const wheel of this.wheels) wheel.rotation.x = this.wheelSpin;
    for (const pivot of this.frontPivots) pivot.rotation.y = this.steerVisual * 0.32;
    if (this.shieldMesh) {
      const up = GameManager.Instance.shieldCount > 0;
      this.shieldMesh.visible = up;
      const s = 1 + Math.sin(this.clock * 4) * 0.03;
      this.shieldMesh.scale.setScalar(s);
    }
    if (this.flame) {
      this.flame.visible = this.nitroTimer > 0;
      this.flame.scale.set(1, 1, 0.7 + Math.sin(this.clock * 30) * 0.35);
    }
    this.syncCoins(this.clock);
    this.sun.position.set(this.x + 28, this.y + 42, this.z + 10);
    this.sun.target.position.set(this.x, this.y, this.z);
    if (this.rain && this.rain.visible && this.rainPositions) {
      this.rain.position.set(this.camera.position.x, this.camera.position.y - 4, this.camera.position.z);
      const arr = this.rainPositions;
      for (let i = 0; i < arr.length; i += 3) {
        arr[i + 1] -= dt * 22;
        if (arr[i + 1] < -8) arr[i + 1] = 14;
      }
      const attr = this.rain.geometry.getAttribute("position");
      attr.needsUpdate = true;
    }
    this.world.traverse((obj) => {
      if (obj.name === "cloud") obj.position.x += dt * 0.8;
    });
  }

  private updateCamera(dt: number) {
    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const gm = GameManager.Instance;
    const weather = gm.weather === "auto" ? this.level.weather : gm.weather;
    if (this.phase === "menu") {
      this.previewS += dt * 0.012;
      if (this.previewS > 0.62) this.previewS = 0.02;
      const a = pointAlong(this.track, this.previewS);
      const b = pointAlong(this.track, Math.min(0.96, this.previewS + 0.045));
      this.camPos.lerp(new THREE.Vector3(a.x - a.tx * 14 + a.rx * 3, a.y + 7.2, a.z - a.tz * 14 + a.rz * 3), this.camReady ? 1 - Math.exp(-1.6 * dt) : 1);
      this.lookSmooth.lerp(new THREE.Vector3(b.x, b.y + 1.6, b.z), this.camReady ? 1 - Math.exp(-1.8 * dt) : 1);
      this.camReady = true;
    } else {
      const hood = gm.camera === "hood";
      const dist = weather === "fog" ? 8.2 : 11;
      const desired = hood
        ? new THREE.Vector3(this.x + fx * 0.2, this.y + 1.28, this.z + fz * 0.2)
        : new THREE.Vector3(this.x - fx * dist, this.y + 4.3, this.z - fz * dist);
      const lookAt = hood
        ? new THREE.Vector3(this.x + fx * 16, this.y + 1.05, this.z + fz * 16)
        : new THREE.Vector3(this.x + fx * 7, this.y + 1.25, this.z + fz * 7);
      const k = 1 - Math.exp(-(hood ? 8 : 4.5) * dt);
      if (!this.camReady) {
        this.camPos.copy(desired);
        this.lookSmooth.copy(lookAt);
        this.camReady = true;
      } else {
        this.camPos.lerp(desired, k);
        this.lookSmooth.lerp(lookAt, k);
      }
    }
    if (this.shake > 0) {
      this.shake = Math.max(0, this.shake - dt);
      this.camPos.x += (Math.random() - 0.5) * this.shake;
      this.camPos.y += (Math.random() - 0.5) * this.shake * 0.6;
    }
    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.lookSmooth);
    const fov = 66 + Math.min(14, Math.abs(this.speed) * 0.32) + (this.nitroTimer > 0 ? 6 : 0);
    this.camera.fov += (fov - this.camera.fov) * Math.min(1, dt * 3);
    this.camera.updateProjectionMatrix();
  }

  private drawMinimap() {
    const canvas = this.minimap;
    if (!canvas || this.track.length < 2) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const w = canvas.width;
    const h = canvas.height;
    let minX = Infinity;
    let maxX = -Infinity;
    let minZ = Infinity;
    let maxZ = -Infinity;
    for (const p of this.track) {
      minX = Math.min(minX, p.x);
      maxX = Math.max(maxX, p.x);
      minZ = Math.min(minZ, p.z);
      maxZ = Math.max(maxZ, p.z);
    }
    const pad = 10;
    const s = Math.min((w - pad * 2) / (maxX - minX || 1), (h - pad * 2) / (maxZ - minZ || 1));
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(7,17,13,0.72)";
    ctx.fillRect(0, 0, w, h);
    ctx.beginPath();
    this.track.forEach((p, i) => {
      const X = pad + (p.x - minX) * s;
      const Y = pad + (p.z - minZ) * s;
      if (i === 0) ctx.moveTo(X, Y);
      else ctx.lineTo(X, Y);
    });
    ctx.strokeStyle = "#e4b15a";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = "#e25b3a";
    ctx.beginPath();
    ctx.arc(pad + (this.x - minX) * s, pad + (this.z - minZ) * s, 3.5, 0, Math.PI * 2);
    ctx.fill();
  }
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}
