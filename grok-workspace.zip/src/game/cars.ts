export type CarDef = {
  id: string;
  name: string;
  bn: string;
  color: string;
  price: number;
  maxSpeed: number;
  accel: number;
  brake: number;
  turn: number;
  grip: number;
};

export const CARS: CarDef[] = [
  {
    id: "red",
    name: "Crimson",
    bn: "লাল স্পোর্টস",
    color: "#d23a32",
    price: 0,
    maxSpeed: 36,
    accel: 18,
    brake: 28,
    turn: 1.55,
    grip: 1,
  },
  {
    id: "white",
    name: "Ivory",
    bn: "সাদা স্পোর্টস",
    color: "#f3f0e8",
    price: 800,
    maxSpeed: 34,
    accel: 23,
    brake: 26,
    turn: 1.5,
    grip: 0.96,
  },
  {
    id: "black",
    name: "Midnight",
    bn: "কালো স্পোর্টস",
    color: "#16171e",
    price: 1400,
    maxSpeed: 42,
    accel: 16,
    brake: 24,
    turn: 1.38,
    grip: 0.9,
  },
  {
    id: "blue",
    name: "Azure",
    bn: "নীল স্পোর্টস",
    color: "#2c6bed",
    price: 2000,
    maxSpeed: 35,
    accel: 19,
    brake: 30,
    turn: 1.85,
    grip: 1.12,
  },
  {
    id: "green",
    name: "Emerald",
    bn: "সবুজ স্পোর্টস",
    color: "#1c9a5e",
    price: 2600,
    maxSpeed: 37,
    accel: 20,
    brake: 34,
    turn: 1.6,
    grip: 1.05,
  },
];

export function getCar(id: string) {
  return CARS.find((car) => car.id === id) ?? CARS[0];
}

export function statPercent(value: number, max: number) {
  return Math.max(6, Math.min(100, Math.round((value / max) * 100)));
}
