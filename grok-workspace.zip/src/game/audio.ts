export class RaceAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private engineGain: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private musicTime = 0;
  private step = 0;
  soundOn = true;
  musicOn = true;

  unlock() {
    if (typeof window === "undefined") return;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    if (!this.ctx) {
      const ctx = new AC({ latencyHint: "interactive" });
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.musicBus = ctx.createGain();
      this.sfxBus = ctx.createGain();
      this.musicBus.connect(this.master);
      this.sfxBus.connect(this.master);
      this.master.connect(ctx.destination);
      this.engineOsc = ctx.createOscillator();
      this.engineOsc.type = "sawtooth";
      this.engineFilter = ctx.createBiquadFilter();
      this.engineFilter.type = "lowpass";
      this.engineFilter.frequency.value = 420;
      this.engineGain = ctx.createGain();
      this.engineGain.gain.value = 0;
      this.engineOsc.connect(this.engineFilter);
      this.engineFilter.connect(this.engineGain);
      this.engineGain.connect(this.sfxBus);
      this.engineOsc.start();
      const noise = ctx.createBuffer(1, ctx.sampleRate * 0.4, ctx.sampleRate);
      const data = noise.getChannelData(0);
      for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
      this.noise = noise;
      this.applyFlags();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  setFlags(soundOn: boolean, musicOn: boolean) {
    this.soundOn = soundOn;
    this.musicOn = musicOn;
    this.applyFlags();
  }

  private applyFlags() {
    if (!this.ctx || !this.sfxBus || !this.musicBus) return;
    const now = this.ctx.currentTime;
    this.sfxBus.gain.setTargetAtTime(this.soundOn ? 0.9 : 0, now, 0.03);
    this.musicBus.gain.setTargetAtTime(this.musicOn ? 0.22 : 0, now, 0.05);
  }

  resume() {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  updateEngine(speed: number, throttle: number, racing: boolean) {
    if (!this.ctx || !this.engineOsc || !this.engineGain || !this.engineFilter) return;
    const now = this.ctx.currentTime;
    const hear = racing && this.soundOn;
    const freq = 52 + Math.abs(speed) * 2.15 + (throttle > 0 ? 28 : 0);
    this.engineOsc.frequency.setTargetAtTime(freq, now, 0.05);
    this.engineFilter.frequency.setTargetAtTime(380 + Math.abs(speed) * 18, now, 0.08);
    const gain = hear ? 0.018 + Math.min(0.06, Math.abs(speed) * 0.0016) + throttle * 0.02 : 0;
    this.engineGain.gain.setTargetAtTime(gain, now, 0.05);
  }

  updateMusic(dt: number, allow: boolean) {
    if (!allow || !this.musicOn) return;
    this.musicTime += dt;
    if (this.musicTime < 0.48) return;
    this.musicTime = 0;
    const notes = [196, 247, 294, 330, 392, 330, 294, 247];
    this.tone(notes[this.step % notes.length], 0.22, "sine", 0.08, true);
    this.step += 1;
  }

  coin() {
    this.tone(880, 0.08, "sine", 0.12, false);
    this.tone(1320, 0.1, "triangle", 0.06, false);
  }

  crash() {
    this.burst(0.28, 180);
    this.tone(90, 0.18, "square", 0.08, false);
  }

  shield() {
    this.tone(520, 0.12, "sine", 0.1, false);
    this.tone(780, 0.16, "triangle", 0.08, false);
  }

  nitro() {
    this.tone(180, 0.25, "sawtooth", 0.07, false);
    this.tone(420, 0.2, "square", 0.04, false);
  }

  scrape() {
    this.burst(0.08, 900);
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, music: boolean) {
    if (!this.ctx || !this.sfxBus || !this.musicBus) return;
    if (music && !this.musicOn) return;
    if (!music && !this.soundOn) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    const now = this.ctx.currentTime;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.001, vol), now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    osc.connect(gain);
    gain.connect(music ? this.musicBus : this.sfxBus);
    osc.start(now);
    osc.stop(now + dur + 0.02);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  }

  private burst(dur: number, freq: number) {
    if (!this.ctx || !this.noise || !this.sfxBus || !this.soundOn) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noise;
    const filter = this.ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = freq;
    const gain = this.ctx.createGain();
    const now = this.ctx.currentTime;
    gain.gain.setValueAtTime(0.18, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxBus);
    src.start(now);
    src.stop(now + dur);
    src.onended = () => {
      src.disconnect();
      filter.disconnect();
      gain.disconnect();
    };
  }
}
