import { useEffect, useRef, useState, type PointerEvent, type ReactNode } from "react";
import {
  Bell,
  BellOff,
  ChevronLeft,
  Coins,
  Flag,
  Gauge,
  Lock,
  Mountain,
  Music,
  Pause,
  RotateCcw,
  Settings,
  Shield,
  Smartphone,
  Star,
  Volume2,
  VolumeX,
  Zap,
} from "lucide-react";
import { CARS, getCar, statPercent } from "@/game/cars";
import { GameEngine, type FinishResult, type HeldAction, type HudState } from "@/game/engine";
import { GameManager } from "@/game/game-manager";
import { getLevel, LEVEL_COUNT, WEATHER_LABEL } from "@/game/levels";
import type { WeatherChoice } from "@/game/game-manager";

type Screen = "menu" | "garage" | "levels" | "settings" | "race" | "pause" | "results";

const EMPTY_HUD: HudState = {
  speedKmh: 0,
  time: 0,
  progress: 0,
  coinsRun: 0,
  crashes: 0,
  drift: 0,
  wrongWay: false,
  nitroOn: false,
};

function formatTime(time: number) {
  const m = Math.floor(time / 60);
  const s = Math.floor(time % 60);
  const cs = Math.floor((time % 1) * 100);
  return `${m}:${s.toString().padStart(2, "0")}.${cs.toString().padStart(2, "0")}`;
}

export function MountainRush() {
  const hostRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const pendingStart = useRef(false);
  const [screen, setScreen] = useState<Screen>("menu");
  const [hud, setHud] = useState<HudState>(EMPTY_HUD);
  const [result, setResult] = useState<FinishResult | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [giftNote, setGiftNote] = useState<string | null>(null);
  const [bootError, setBootError] = useState<string | null>(null);
  const [profile, setProfile] = useState(0);

  useEffect(() => {
    const gm = GameManager.Instance;
    const unsub = gm.subscribe(() => setProfile((n) => n + 1));
    gm.LoadGameData();
    const host = hostRef.current;
    if (!host) return unsub;
    const engine = new GameEngine(host, {
      onHud: setHud,
      onFinish: (next) => {
        setResult(next);
        setScreen("results");
      },
      onNotice: setNote,
      onBootError: setBootError,
    });
    engineRef.current = engine;
    if (pendingStart.current) {
      pendingStart.current = false;
      engine.startRace();
      setScreen("race");
    }
    return () => {
      unsub();
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!note) return;
    const id = window.setTimeout(() => setNote(null), 2400);
    return () => window.clearTimeout(id);
  }, [note]);

  const gm = GameManager.Instance;
  const level = getLevel(gm.selectedLevel);
  const car = getCar(gm.selectedCar);
  void profile;

  function start() {
    const engine = engineRef.current;
    if (!engine) {
      pendingStart.current = true;
      setScreen("race");
      return;
    }
    engine.startRace();
    setScreen("race");
  }

  function hold(action: HeldAction, down: boolean) {
  return (event: PointerEvent<HTMLButtonElement>) => {
      event.preventDefault();
      if (down) event.currentTarget.setPointerCapture(event.pointerId);
      engineRef.current?.setHeld(action, down);
    };
  }

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-ink">
      <div ref={hostRef} className="absolute inset-0" />
      {bootError ? (
        <p className="absolute inset-x-0 top-6 z-30 px-4 text-center text-sm text-gold">{bootError}</p>
      ) : null}
      {note && gm.isNotificationOn ? (
        <p className="absolute top-16 left-1/2 z-40 max-w-xs -translate-x-1/2 rounded-full border border-line bg-panel px-4 py-2 text-center text-sm text-ink">
          {note}
        </p>
      ) : null}

      {screen === "menu" || screen === "garage" || screen === "levels" || screen === "settings" ? (
        <MenuChrome
          screen={screen}
          setScreen={setScreen}
          levelName={`${level.bn}`}
          levelEn={level.name}
          carName={car.bn}
          giftNote={giftNote}
          onGift={() => setGiftNote(gm.ClaimDailyGift())}
          onStart={start}
          onSelectLevel={(id) => engineRef.current?.previewLevel(id)}
          onSelectCar={(id) => engineRef.current?.setCar(id)}
          onAudio={() => engineRef.current?.applyAudio()}
          onWeather={() => engineRef.current?.refreshWeather()}
          onReset={() => {
            GameManager.Instance.ResetProgress();
            engineRef.current?.previewLevel(1);
            engineRef.current?.setCar("red");
          }}
        />
      ) : null}

      {screen === "race" || screen === "pause" ? (
        <RaceHud
          hud={hud}
          levelBn={level.bn}
          screen={screen}
          onPause={() => {
            engineRef.current?.pause();
            setScreen("pause");
          }}
          onResume={() => {
            engineRef.current?.resume();
            setScreen("race");
          }}
          onQuit={() => {
            engineRef.current?.toMenu();
            setScreen("menu");
          }}
          onNitro={() => engineRef.current?.activateNitro()}
          onRescue={() => engineRef.current?.rescue()}
          hold={hold}
          mapRef={(node) => engineRef.current?.setMinimap(node)}
        />
      ) : null}

      {screen === "results" && result ? (
        <Results
          result={result}
          onRetry={start}
          onNext={() => {
            const next = Math.min(LEVEL_COUNT, result.level + 1);
            gm.selectedLevel = next;
            gm.SaveGameData();
            engineRef.current?.previewLevel(next);
            start();
          }}
          onMenu={() => {
            engineRef.current?.toMenu();
            setScreen("menu");
          }}
        />
      ) : null}
    </main>
  );
}

function Wallet() {
  const gm = GameManager.Instance;
  return (
    <div className="flex shrink-0 items-center gap-1">
      <span className="inline-flex items-center gap-1 rounded-full border border-line bg-panel/90 px-2 py-1 text-xs text-gold">
        <Coins className="size-3.5" />
        {gm.totalCoins}
      </span>
      <span className="inline-flex items-center gap-1 rounded-full border border-line bg-panel/90 px-2 py-1 text-xs">
        <Zap className="size-3.5 text-gold" />
        {gm.nitroBoostCount}
      </span>
      <span className="inline-flex items-center gap-1 rounded-full border border-line bg-panel/90 px-2 py-1 text-xs">
        <Shield className="size-3.5 text-pine" />
        {gm.shieldCount}
      </span>
    </div>
  );
}

function MenuChrome({
  screen,
  setScreen,
  levelName,
  levelEn,
  carName,
  giftNote,
  onGift,
  onStart,
  onSelectLevel,
  onSelectCar,
  onAudio,
  onWeather,
  onReset,
}: {
  screen: Screen;
  setScreen: (screen: Screen) => void;
  levelName: string;
  levelEn: string;
  carName: string;
  giftNote: string | null;
  onGift: () => void;
  onStart: () => void;
  onSelectLevel: (id: number) => void;
  onSelectCar: (id: string) => void;
  onAudio: () => void;
  onWeather: () => void;
  onReset: () => void;
}) {
  const gm = GameManager.Instance;
  return (
    <div className="absolute inset-0 z-20 flex flex-col">
      <div className="scrim-top pointer-events-none absolute inset-x-0 top-0 h-36" />
      <header className="relative flex flex-col gap-3 p-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="font-display text-xs tracking-widest text-gold">MOUNTAIN RUSH</p>
          <h1 className="font-display text-3xl leading-none text-ink sm:text-5xl">Mountain Rush 3D</h1>
          <p className="mt-1 text-sm text-muted">পাহাড়ি অ্যাডভেঞ্চার রেস</p>
        </div>
        <Wallet />
      </header>
      <div className="flex-1" />
      <div className="scrim-bottom px-4 pt-16 pb-4">
        <div className="mx-auto w-full max-w-lg">
          {screen === "menu" ? (
            <div className="rounded-2xl border border-line bg-panel/90 p-4">
              <div className="mb-4 flex items-center justify-between gap-3 text-sm">
                <div>
                  <p className="text-muted">পর্ব {gm.selectedLevel}</p>
                  <p className="font-display text-lg text-ink">{levelName}</p>
                  <p className="text-xs text-muted">{levelEn}</p>
                </div>
                <div className="text-right">
                  <p className="text-muted">গাড়ি</p>
                  <p className="font-display text-lg">{carName}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={onStart}
                className="flex h-14 w-full flex-col items-center justify-center rounded-xl bg-ember text-bg"
              >
                <span className="font-display text-2xl leading-none">Start</span>
                <span className="text-xs font-medium">খেলো</span>
              </button>
              <div className="mt-3 grid grid-cols-3 gap-2">
                <MiniButton icon={<Mountain className="size-4" />} label="গ্যারেজ" onClick={() => setScreen("garage")} />
                <MiniButton icon={<Flag className="size-4" />} label="পর্ব" onClick={() => setScreen("levels")} />
                <MiniButton icon={<Settings className="size-4" />} label="সেটিংস" onClick={() => setScreen("settings")} />
              </div>
              <button
                type="button"
                onClick={onGift}
                className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-line bg-panel-2 text-sm text-gold"
              >
                <Coins className="size-4" />
                ডেইলি গিফট +{gm.dailyGiftAmount}
              </button>
              {giftNote ? <p className="mt-2 text-center text-sm text-ink">{giftNote}</p> : null}
              {gm.isNotificationOn && gm.giftAvailable() ? (
                <p className="mt-2 text-center text-xs text-muted">আজকের উপহার অপেক্ষা করছে।</p>
              ) : null}
            </div>
          ) : null}
          {screen === "garage" ? (
            <Sheet title="গ্যারেজ" onBack={() => setScreen("menu")}>
              <ul className="flex flex-col gap-2">
                {CARS.map((item) => {
                  const owned = gm.ownedCars.includes(item.id);
                  const selected = gm.selectedCar === item.id;
                  return (
                    <li key={item.id} className={`rounded-xl border p-3 ${selected ? "border-gold bg-panel-2" : "border-line"}`}>
                      <div className="flex items-center gap-3">
                        <span className="size-10 shrink-0 rounded-lg border border-line" style={{ background: item.color }} />
                        <div className="min-w-0 flex-1">
                          <p className="font-display text-lg leading-tight">{item.bn}</p>
                          <p className="text-xs text-muted">{item.name}</p>
                        </div>
                        {owned ? (
                          <button
                            type="button"
                            onClick={() => onSelectCar(item.id)}
                            className="h-11 rounded-lg bg-pine px-3 text-sm text-ink"
                          >
                            {selected ? "নির্বাচিত" : "বেছে নাও"}
                          </button>
                        ) : (
                          <button
                            type="button"
                            disabled={gm.totalCoins < item.price}
                            onClick={() => {
                              if (!gm.TrySpend(item.price)) return;
                              gm.ownedCars = [...gm.ownedCars, item.id];
                              gm.SaveGameData();
                              onSelectCar(item.id);
                            }}
                            className="h-11 rounded-lg bg-gold px-3 text-sm text-bg disabled:opacity-40"
                          >
                            {item.price}
                          </button>
                        )}
                      </div>
                      <div className="mt-3 grid grid-cols-5 gap-2">
                        <Bar label="স্পিড" value={statPercent(item.maxSpeed, 42)} />
                        <Bar label="অ্যাক্সেল" value={statPercent(item.accel, 23)} />
                        <Bar label="ব্রেক" value={statPercent(item.brake, 34)} />
                        <Bar label="হ্যান্ডল" value={statPercent(item.turn, 1.85)} />
                        <Bar label="গ্রিপ" value={statPercent(item.grip, 1.12)} />
                      </div>
                    </li>
                  );
                })}
              </ul>
            </Sheet>
          ) : null}
          {screen === "levels" ? (
            <Sheet title="পর্বসমূহ" onBack={() => setScreen("menu")}>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {Array.from({ length: LEVEL_COUNT }, (_, index) => {
                  const id = index + 1;
                  const def = getLevel(id);
                  const locked = id > gm.unlockedLevel;
                  const best = gm.best[String(id)];
                  return (
                    <button
                      key={id}
                      type="button"
                      disabled={locked}
                      onClick={() => onSelectLevel(id)}
                      className={`min-h-16 rounded-xl border p-2 text-left ${
                        gm.selectedLevel === id ? "border-gold bg-panel-2" : "border-line"
                      } disabled:opacity-45`}
                    >
                      <span className="flex items-center justify-between text-xs text-muted">
                        পর্ব {id}
                        {locked ? <Lock className="size-3.5" /> : <span>{WEATHER_LABEL[def.weather]}</span>}
                      </span>
                      <span className="mt-1 block text-sm leading-tight">{def.bn}</span>
                      {best ? <span className="mt-1 block text-xs text-gold">{formatTime(best.time)}</span> : null}
                    </button>
                  );
                })}
              </div>
            </Sheet>
          ) : null}
          {screen === "settings" ? (
            <Sheet title="সেটিংস" onBack={() => setScreen("menu")}>
              <SettingsPanel onAudio={onAudio} onWeather={onWeather} onReset={onReset} />
            </Sheet>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function MiniButton({ icon, label, onClick }: { icon: ReactNode; label: string; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex h-12 flex-col items-center justify-center gap-0.5 rounded-xl border border-line bg-panel-2 text-xs">
      {icon}
      {label}
    </button>
  );
}

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="mb-1 h-1.5 overflow-hidden rounded-full bg-bg">
        <div className="h-full bg-gold" style={{ width: `${value}%` }} />
      </div>
      <p className="text-center text-xs text-muted">{label}</p>
    </div>
  );
}

function Sheet({ title, onBack, children }: { title: string; onBack: () => void; children: ReactNode }) {
  return (
    <section className="max-h-[68dvh] overflow-y-auto rounded-2xl border border-line bg-panel/95 p-4">
      <div className="mb-3 flex items-center gap-2">
        <button type="button" onClick={onBack} className="grid size-11 place-items-center rounded-xl border border-line" aria-label="ফিরে যাও">
          <ChevronLeft className="size-5" />
        </button>
        <h2 className="font-display text-2xl">{title}</h2>
      </div>
      {children}
    </section>
  );
}

function SettingsPanel({ onAudio, onWeather, onReset }: { onAudio: () => void; onWeather: () => void; onReset: () => void }) {
  const gm = GameManager.Instance;
  const weatherOptions: { id: WeatherChoice; label: string }[] = [
    { id: "auto", label: "লেভেল" },
    { id: "sunrise", label: WEATHER_LABEL.sunrise },
    { id: "day", label: WEATHER_LABEL.day },
    { id: "sunset", label: WEATHER_LABEL.sunset },
    { id: "night", label: WEATHER_LABEL.night },
    { id: "fog", label: WEATHER_LABEL.fog },
    { id: "storm", label: WEATHER_LABEL.storm },
  ];
  return (
    <div className="flex flex-col gap-2">
      <Toggle
        label="সাউন্ড"
        on={gm.isSoundOn}
        icon={gm.isSoundOn ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
        onClick={() => {
          gm.ToggleSound(!gm.isSoundOn);
          onAudio();
        }}
      />
      <Toggle
        label="মিউজিক"
        on={gm.isMusicOn}
        icon={<Music className="size-4" />}
        onClick={() => {
          gm.ToggleMusic(!gm.isMusicOn);
          onAudio();
        }}
      />
      <Toggle
        label="নোটিফিকেশন"
        on={gm.isNotificationOn}
        icon={gm.isNotificationOn ? <Bell className="size-4" /> : <BellOff className="size-4" />}
        onClick={() => gm.ToggleNotification(!gm.isNotificationOn)}
      />
      <div className="rounded-xl border border-line p-3">
        <p className="mb-2 text-sm text-muted">স্টিয়ারিং</p>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => gm.SetSteeringMode(false)}
            className={`h-11 rounded-lg border text-sm ${gm.useTiltSteering ? "border-line" : "border-gold bg-panel-2"}`}
          >
            বাটন
          </button>
          <button
            type="button"
            onClick={() => void enableTilt()}
            className={`flex h-11 items-center justify-center gap-1 rounded-lg border text-sm ${gm.useTiltSteering ? "border-gold bg-panel-2" : "border-line"}`}
          >
            <Smartphone className="size-4" />
            টিল্ট
          </button>
        </div>
        <label className="mt-3 block text-sm text-muted">
          সেন্সিটিভিটি {gm.steeringSensitivity.toFixed(2)}
          <input
            className="mt-2 w-full accent-gold"
            type="range"
            min={0.5}
            max={2}
            step={0.05}
            value={gm.steeringSensitivity}
            onChange={(event) => gm.SetSensitivity(Number(event.target.value))}
          />
        </label>
      </div>
      <div className="rounded-xl border border-line p-3">
        <p className="mb-2 text-sm text-muted">ক্যামেরা</p>
        <div className="grid grid-cols-2 gap-2">
          {(["chase", "hood"] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => {
                gm.camera = mode;
                gm.SaveGameData();
              }}
              className={`h-11 rounded-lg border text-sm ${gm.camera === mode ? "border-gold bg-panel-2" : "border-line"}`}
            >
              {mode === "chase" ? "পিছন থেকে" : "হুড"}
            </button>
          ))}
        </div>
      </div>
      <div className="rounded-xl border border-line p-3">
        <p className="mb-2 text-sm text-muted">আবহাওয়া</p>
        <div className="flex flex-wrap gap-2">
          {weatherOptions.map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => {
                gm.weather = option.id;
                gm.SaveGameData();
                onWeather();
              }}
              className={`h-10 rounded-lg border px-3 text-sm ${gm.weather === option.id ? "border-gold text-gold" : "border-line"}`}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>
      <button
        type="button"
        onClick={onReset}
        className="h-11 rounded-xl border border-ember text-sm text-ember"
      >
        প্রোগ্রেস মুছে ফেলো
      </button>
    </div>
  );
}

async function enableTilt() {
  const ctor = DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
  if (typeof ctor.requestPermission === "function") {
    try {
      const result = await ctor.requestPermission();
      if (result !== "granted") return;
    } catch {
      return;
    }
  }
  GameManager.Instance.SetSteeringMode(true);
}

function Toggle({ label, on, icon, onClick }: { label: string; on: boolean; icon: ReactNode; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex h-12 items-center justify-between rounded-xl border border-line px-3 text-sm">
      <span className="inline-flex items-center gap-2">
        {icon}
        {label}
      </span>
      <span className={on ? "text-gold" : "text-muted"}>{on ? "চালু" : "বন্ধ"}</span>
    </button>
  );
}

function RaceHud({
  hud,
  levelBn,
  screen,
  onPause,
  onResume,
  onQuit,
  onNitro,
  onRescue,
  hold,
  mapRef,
}: {
  hud: HudState;
  levelBn: string;
  screen: Screen;
  onPause: () => void;
  onResume: () => void;
  onQuit: () => void;
  onNitro: () => void;
  onRescue: () => void;
  hold: (action: HeldAction, down: boolean) => (event: PointerEvent<HTMLButtonElement>) => void;
  mapRef: (node: HTMLCanvasElement | null) => void;
}) {
  const gm = GameManager.Instance;
  return (
    <div className="pointer-events-none absolute inset-0 z-20">
      <div className="pointer-events-auto absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3">
        <button type="button" onClick={onPause} className="grid size-11 place-items-center rounded-xl border border-line bg-panel/90" aria-label="পজ">
          <Pause className="size-5" />
        </button>
        <div className="min-w-0 rounded-xl border border-line bg-panel/90 px-3 py-2 text-center">
          <p className="truncate text-xs text-muted">{levelBn}</p>
          <p className="font-display text-lg tabular-nums">{formatTime(hud.time)}</p>
        </div>
        <Wallet />
      </div>
      <div className="absolute top-20 left-3 flex items-end gap-3">
        <div>
          <p className="font-display text-4xl tabular-nums leading-none">{hud.speedKmh}</p>
          <p className="text-xs text-muted">km/h</p>
        </div>
        <canvas ref={mapRef} width={148} height={96} className="hidden rounded-lg border border-line sm:block" />
      </div>
      <div className="absolute top-20 right-3 flex flex-col items-end gap-2">
        <button type="button" onClick={onNitro} className="pointer-events-auto inline-flex h-11 items-center gap-1 rounded-xl bg-gold px-3 text-sm text-bg">
          <Zap className="size-4" />
          নাইট্রো {gm.nitroBoostCount}
        </button>
        <span className="inline-flex items-center gap-1 rounded-full bg-panel/90 px-2 py-1 text-xs">
          <Shield className="size-3.5 text-pine" />
          {gm.shieldCount}
        </span>
        <button type="button" onClick={onRescue} className="pointer-events-auto inline-flex h-11 items-center gap-1 rounded-xl border border-line bg-panel/90 px-3 text-xs">
          <RotateCcw className="size-4" />
          রেসকিউ
        </button>
      </div>
      <div className="absolute top-36 right-3 left-3 sm:left-40 sm:right-auto sm:w-48">
        <div className="h-1.5 overflow-hidden rounded-full bg-panel">
          <div className="h-full bg-pine" style={{ width: `${Math.round(hud.progress * 100)}%` }} />
        </div>
        {hud.drift > 0.05 ? (
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-panel">
            <div className="h-full bg-ember" style={{ width: `${Math.round(hud.drift * 100)}%` }} />
          </div>
        ) : null}
        {hud.wrongWay ? <p className="mt-1 text-sm text-ember">উল্টো দিক</p> : null}
        {hud.nitroOn ? <p className="mt-1 text-xs text-gold">নাইট্রো</p> : null}
      </div>
      <p className="absolute bottom-4 left-4 hidden items-center gap-2 text-xs text-muted md:flex">
        <Gauge className="size-4" />
        W অ্যাক্সেল · S ব্রেক · A/D স্টিয়ার · Space ড্রিফট · R রিভার্স · N নাইট্রো
      </p>
      {screen === "race" ? (
        <div className="pointer-events-auto absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-3 md:hidden">
          <div className="flex gap-2">
            <Control label="বাঁ" onDown={hold("left", true)} onUp={hold("left", false)} />
            <Control label="ডান" onDown={hold("right", true)} onUp={hold("right", false)} />
          </div>
          <div className="flex flex-col items-end gap-2">
            <button
              type="button"
              className="h-16 w-28 rounded-2xl bg-ember text-sm font-semibold text-bg"
              onPointerDown={hold("throttle", true)}
              onPointerUp={hold("throttle", false)}
              onPointerCancel={hold("throttle", false)}
            >
              ACCEL
            </button>
            <div className="flex gap-2">
              <SmallControl label="BRAKE" action="brake" hold={hold} />
              <SmallControl label="DRIFT" action="handbrake" hold={hold} />
              <SmallControl label="REV" action="reverse" hold={hold} />
            </div>
          </div>
        </div>
      ) : null}
      {screen === "pause" ? (
        <div className="pointer-events-auto absolute inset-0 grid place-items-center bg-bg/70 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-line bg-panel p-4">
            <h2 className="font-display text-3xl">পজ</h2>
            <div className="mt-4 flex flex-col gap-2">
              <button type="button" onClick={onResume} className="h-12 rounded-xl bg-ember text-bg">
                চালিয়ে যাও
              </button>
              <button type="button" onClick={onQuit} className="h-12 rounded-xl border border-line">
                মেনু
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Control({
  label,
  onDown,
  onUp,
}: {
  label: string;
  onDown: (event: PointerEvent<HTMLButtonElement>) => void;
  onUp: (event: PointerEvent<HTMLButtonElement>) => void;
}) {
  return (
    <button
      type="button"
      className="grid size-16 place-items-center rounded-2xl border border-line bg-panel/90 text-sm"
      onPointerDown={onDown}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      onContextMenu={(event) => event.preventDefault()}
    >
      {label}
    </button>
  );
}

function SmallControl({
  label,
  action,
  hold,
}: {
  label: string;
  action: HeldAction;
  hold: (action: HeldAction, down: boolean) => (event: PointerEvent<HTMLButtonElement>) => void;
}) {
  return (
    <button
      type="button"
      className="h-12 min-w-16 rounded-xl border border-line bg-panel/90 px-2 text-xs"
      onPointerDown={hold(action, true)}
      onPointerUp={hold(action, false)}
      onPointerCancel={hold(action, false)}
    >
      {label}
    </button>
  );
}

function Results({
  result,
  onRetry,
  onNext,
  onMenu,
}: {
  result: FinishResult;
  onRetry: () => void;
  onNext: () => void;
  onMenu: () => void;
}) {
  const level = getLevel(result.level);
  return (
    <div className="absolute inset-0 z-30 grid place-items-center bg-bg/75 p-4">
      <div className="w-full max-w-md rounded-2xl border border-line bg-panel p-5">
        <p className="text-sm text-gold">পর্ব {result.level} সম্পন্ন</p>
        <h2 className="font-display text-3xl">{level.bn}</h2>
        <div className="mt-3 flex gap-1 text-gold">
          {[1, 2, 3].map((star) => (
            <Star key={star} className={`size-6 ${star <= result.stars ? "fill-gold" : "text-line"}`} />
          ))}
        </div>
        <dl className="mt-4 grid grid-cols-3 gap-2 text-center text-sm">
          <div className="rounded-xl bg-panel-2 p-2">
            <dt className="text-muted">সময়</dt>
            <dd className="tabular-nums">{formatTime(result.time)}</dd>
          </div>
          <div className="rounded-xl bg-panel-2 p-2">
            <dt className="text-muted">কয়েন</dt>
            <dd>{result.coinsRun}</dd>
          </div>
          <div className="rounded-xl bg-panel-2 p-2">
            <dt className="text-muted">ক্র্যাশ</dt>
            <dd>{result.crashes}</dd>
          </div>
        </dl>
        <p className="mt-4 text-sm leading-relaxed">{result.rewardText}</p>
        <div className="mt-4 flex flex-col gap-2">
          {result.level < LEVEL_COUNT ? (
            <button type="button" onClick={onNext} className="h-12 rounded-xl bg-ember text-bg">
              পরের পর্ব
            </button>
          ) : null}
          <button type="button" onClick={onRetry} className="h-12 rounded-xl border border-line">
            আবার
          </button>
          <button type="button" onClick={onMenu} className="h-12 rounded-xl border border-line">
            মেনু
          </button>
        </div>
      </div>
    </div>
  );
}
