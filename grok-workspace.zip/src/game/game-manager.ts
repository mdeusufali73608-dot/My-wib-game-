const STORAGE_KEY = "mountain-rush-gm-v1";

export type BestRun = { time: number; stars: number };

export type WeatherChoice = "auto" | "sunrise" | "day" | "sunset" | "night" | "fog" | "storm";

export type GameData = {
  version: 1;
  totalCoins: number;
  nitroBoostCount: number;
  shieldCount: number;
  isSoundOn: boolean;
  isMusicOn: boolean;
  isNotificationOn: boolean;
  useTiltSteering: boolean;
  steeringSensitivity: number;
  dailyGiftAmount: number;
  lastGiftDate: string;
  ownedCars: string[];
  selectedCar: string;
  selectedLevel: number;
  unlockedLevel: number;
  best: Record<string, BestRun>;
  camera: "chase" | "hood";
  weather: WeatherChoice;
};

const WEATHERS: WeatherChoice[] = ["auto", "sunrise", "day", "sunset", "night", "fog", "storm"];

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function num(v: unknown, fallback: number) {
  return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}

function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

/**
 * Browser port of the Unity GameManager: one persistent profile
 * (coins, nitro, shield, settings, daily gift, win rewards).
 */
export class GameManager {
  static Instance = new GameManager();

  totalCoins = 1000;
  nitroBoostCount = 2;
  shieldCount = 1;
  isSoundOn = true;
  isMusicOn = true;
  isNotificationOn = true;
  useTiltSteering = false;
  steeringSensitivity = 1;
  dailyGiftAmount = 250;
  lastGiftDate = "";
  ownedCars: string[] = ["red"];
  selectedCar = "red";
  selectedLevel = 1;
  unlockedLevel = 1;
  best: Record<string, BestRun> = {};
  camera: "chase" | "hood" = "chase";
  weather: WeatherChoice = "auto";

  private listeners = new Set<() => void>();

  subscribe(fn: () => void) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit() {
    for (const fn of this.listeners) fn();
  }

  LoadGameData() {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        this.SaveGameData();
        return;
      }
      const data = JSON.parse(raw) as Partial<GameData>;
      this.totalCoins = Math.max(0, Math.round(num(data.totalCoins, 1000)));
      this.nitroBoostCount = Math.max(0, Math.round(num(data.nitroBoostCount, 2)));
      this.shieldCount = Math.max(0, Math.round(num(data.shieldCount, 1)));
      this.isSoundOn = data.isSoundOn !== false;
      this.isMusicOn = data.isMusicOn !== false;
      this.isNotificationOn = data.isNotificationOn !== false;
      this.useTiltSteering = data.useTiltSteering === true;
      this.steeringSensitivity = clamp(num(data.steeringSensitivity, 1), 0.5, 2);
      this.dailyGiftAmount = Math.max(0, Math.round(num(data.dailyGiftAmount, 250)));
      this.lastGiftDate = typeof data.lastGiftDate === "string" ? data.lastGiftDate : "";
      this.ownedCars = Array.isArray(data.ownedCars) && data.ownedCars.length > 0 ? data.ownedCars.map(String) : ["red"];
      if (!this.ownedCars.includes("red")) this.ownedCars.unshift("red");
      this.selectedCar = typeof data.selectedCar === "string" ? data.selectedCar : "red";
      if (!this.ownedCars.includes(this.selectedCar)) this.selectedCar = "red";
      this.selectedLevel = clamp(Math.round(num(data.selectedLevel, 1)), 1, 30);
      this.unlockedLevel = clamp(Math.round(num(data.unlockedLevel, 1)), 1, 30);
      this.best = data.best && typeof data.best === "object" ? data.best : {};
      this.camera = data.camera === "hood" ? "hood" : "chase";
      this.weather = WEATHERS.includes(data.weather as WeatherChoice) ? (data.weather as WeatherChoice) : "auto";
    } catch {
      /* keep defaults */
    }
    this.emit();
  }

  SaveGameData() {
    if (typeof window === "undefined") return;
    const data: GameData = {
      version: 1,
      totalCoins: this.totalCoins,
      nitroBoostCount: this.nitroBoostCount,
      shieldCount: this.shieldCount,
      isSoundOn: this.isSoundOn,
      isMusicOn: this.isMusicOn,
      isNotificationOn: this.isNotificationOn,
      useTiltSteering: this.useTiltSteering,
      steeringSensitivity: this.steeringSensitivity,
      dailyGiftAmount: this.dailyGiftAmount,
      lastGiftDate: this.lastGiftDate,
      ownedCars: this.ownedCars,
      selectedCar: this.selectedCar,
      selectedLevel: this.selectedLevel,
      unlockedLevel: this.unlockedLevel,
      best: this.best,
      camera: this.camera,
      weather: this.weather,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    this.emit();
  }

  ToggleSound(status: boolean) {
    this.isSoundOn = status;
    this.SaveGameData();
  }

  ToggleMusic(status: boolean) {
    this.isMusicOn = status;
    this.SaveGameData();
  }

  ToggleNotification(status: boolean) {
    this.isNotificationOn = status;
    this.SaveGameData();
  }

  SetSteeringMode(isTilt: boolean) {
    this.useTiltSteering = isTilt;
    this.SaveGameData();
  }

  SetSensitivity(value: number) {
    this.steeringSensitivity = clamp(value, 0.5, 2);
    this.SaveGameData();
  }

  giftAvailable() {
    return this.lastGiftDate !== todayKey();
  }

  ClaimDailyGift(): string {
    if (!this.giftAvailable()) return "আজকের ডেইলি গিফট নেওয়া হয়ে গেছে। কাল আবার এসো।";
    this.totalCoins += this.dailyGiftAmount;
    this.lastGiftDate = todayKey();
    this.SaveGameData();
    return `Daily Gift Claimed! +${this.dailyGiftAmount} Coins`;
  }

  GrantLevelWinReward(levelNumber: number): string {
    const coinReward = 200 + levelNumber * 50;
    this.totalCoins += coinReward;
    const randomGift = 1 + Math.floor(Math.random() * 3);
    let bonusItem = "";
    if (randomGift === 1) {
      this.nitroBoostCount += 1;
      bonusItem = "1x Turbo Nitro Boost";
    } else if (randomGift === 2) {
      this.shieldCount += 1;
      bonusItem = "1x Rock Shield (পাথর থেকে বাঁচাবে)";
    } else {
      this.totalCoins += 150;
      bonusItem = "Extra 150 Bonus Coins!";
    }
    this.SaveGameData();
    return `তুমি জিতেছ: ${coinReward} কয়েন এবং উপহার হিসেবে পেয়েছ: ${bonusItem}`;
  }

  AddCoins(amount: number) {
    this.totalCoins = Math.max(0, this.totalCoins + Math.round(amount));
    this.SaveGameData();
  }

  TrySpend(amount: number) {
    if (this.totalCoins < amount) return false;
    this.totalCoins -= amount;
    this.SaveGameData();
    return true;
  }

  UseNitro() {
    if (this.nitroBoostCount <= 0) return false;
    this.nitroBoostCount -= 1;
    this.SaveGameData();
    return true;
  }

  UseShield() {
    if (this.shieldCount <= 0) return false;
    this.shieldCount -= 1;
    this.SaveGameData();
    return true;
  }

  ResetProgress() {
    const fresh = {
      totalCoins: 1000,
      nitroBoostCount: 2,
      shieldCount: 1,
      lastGiftDate: "",
      ownedCars: ["red"],
      selectedCar: "red",
      selectedLevel: 1,
      unlockedLevel: 1,
      best: {} as Record<string, BestRun>,
    };
    Object.assign(this, fresh);
    this.SaveGameData();
  }
}
