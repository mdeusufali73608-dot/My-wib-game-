import { createFileRoute } from "@tanstack/react-router";
import { MountainRush } from "@/game/MountainRush";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <MountainRush />;
}
