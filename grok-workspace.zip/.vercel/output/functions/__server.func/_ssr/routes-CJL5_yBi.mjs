import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronLeft, a as Star, c as Settings, d as Music, f as Mountain, g as Coins, h as Flag, l as RotateCcw, m as Gauge, n as VolumeX, o as Smartphone, p as Lock, r as Volume2, s as Shield, t as Zap, u as Pause, v as Bell, y as BellOff } from "../_libs/lucide-react.mjs";
import { C as PointsMaterial, D as SpotLight, E as SphereGeometry, O as Timer, S as Points, T as Scene, _ as MeshStandardMaterial, a as CircleGeometry, b as PerspectiveCamera, c as CylinderGeometry, d as Float32BufferAttribute, f as Fog, g as Mesh, h as InstancedMesh, i as BufferGeometry, k as Vector3, l as DirectionalLight, m as HemisphereLight, n as BoxGeometry, o as Color, p as Group, r as BufferAttribute, s as ConeGeometry, t as WebGLRenderer, u as DodecahedronGeometry, v as Object3D, w as SRGBColorSpace, x as PlaneGeometry, y as OctahedronGeometry } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CJL5_yBi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CARS = [
	{
		id: "red",
		name: "Crimson",
		bn: "লাল স্পোর্টস",
		color: "#d23a32",
		price: 0,
		maxSpeed: 36,
		accel: 18,
		brake: 28,
		turn: 1.55,
		grip: 1
	},
	{
		id: "white",
		name: "Ivory",
		bn: "সাদা স্পোর্টস",
		color: "#f3f0e8",
		price: 800,
		maxSpeed: 34,
		accel: 23,
		brake: 26,
		turn: 1.5,
		grip: .96
	},
	{
		id: "black",
		name: "Midnight",
		bn: "কালো স্পোর্টস",
		color: "#16171e",
		price: 1400,
		maxSpeed: 42,
		accel: 16,
		brake: 24,
		turn: 1.38,
		grip: .9
	},
	{
		id: "blue",
		name: "Azure",
		bn: "নীল স্পোর্টস",
		color: "#2c6bed",
		price: 2e3,
		maxSpeed: 35,
		accel: 19,
		brake: 30,
		turn: 1.85,
		grip: 1.12
	},
	{
		id: "green",
		name: "Emerald",
		bn: "সবুজ স্পোর্টস",
		color: "#1c9a5e",
		price: 2600,
		maxSpeed: 37,
		accel: 20,
		brake: 34,
		turn: 1.6,
		grip: 1.05
	}
];
function getCar(id) {
	return CARS.find((car) => car.id === id) ?? CARS[0];
}
function statPercent(value, max) {
	return Math.max(6, Math.min(100, Math.round(value / max * 100)));
}
var RaceAudio = class {
	ctx = null;
	master = null;
	musicBus = null;
	sfxBus = null;
	engineOsc = null;
	engineFilter = null;
	engineGain = null;
	noise = null;
	musicTime = 0;
	step = 0;
	soundOn = true;
	musicOn = true;
	unlock() {
		if (typeof window === "undefined") return;
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return;
		if (!this.ctx) {
			const ctx = new AC({ latencyHint: "interactive" });
			this.ctx = ctx;
			this.master = ctx.createGain();
			this.musicBus = ctx.createGain();
			this.sfxBus = ctx.createGain();
			this.musicBus.connect(this.master);
			this.sfxBus.connect(this.master);
			this.master.connect(ctx.destination);
			this.engineOsc = ctx.createOscillator();
			this.engineOsc.type = "sawtooth";
			this.engineFilter = ctx.createBiquadFilter();
			this.engineFilter.type = "lowpass";
			this.engineFilter.frequency.value = 420;
			this.engineGain = ctx.createGain();
			this.engineGain.gain.value = 0;
			this.engineOsc.connect(this.engineFilter);
			this.engineFilter.connect(this.engineGain);
			this.engineGain.connect(this.sfxBus);
			this.engineOsc.start();
			const noise = ctx.createBuffer(1, ctx.sampleRate * .4, ctx.sampleRate);
			const data = noise.getChannelData(0);
			for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
			this.noise = noise;
			this.applyFlags();
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	setFlags(soundOn, musicOn) {
		this.soundOn = soundOn;
		this.musicOn = musicOn;
		this.applyFlags();
	}
	applyFlags() {
		if (!this.ctx || !this.sfxBus || !this.musicBus) return;
		const now = this.ctx.currentTime;
		this.sfxBus.gain.setTargetAtTime(this.soundOn ? .9 : 0, now, .03);
		this.musicBus.gain.setTargetAtTime(this.musicOn ? .22 : 0, now, .05);
	}
	resume() {
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
	}
	updateEngine(speed, throttle, racing) {
		if (!this.ctx || !this.engineOsc || !this.engineGain || !this.engineFilter) return;
		const now = this.ctx.currentTime;
		const hear = racing && this.soundOn;
		const freq = 52 + Math.abs(speed) * 2.15 + (throttle > 0 ? 28 : 0);
		this.engineOsc.frequency.setTargetAtTime(freq, now, .05);
		this.engineFilter.frequency.setTargetAtTime(380 + Math.abs(speed) * 18, now, .08);
		const gain = hear ? .018 + Math.min(.06, Math.abs(speed) * .0016) + throttle * .02 : 0;
		this.engineGain.gain.setTargetAtTime(gain, now, .05);
	}
	updateMusic(dt, allow) {
		if (!allow || !this.musicOn) return;
		this.musicTime += dt;
		if (this.musicTime < .48) return;
		this.musicTime = 0;
		const notes = [
			196,
			247,
			294,
			330,
			392,
			330,
			294,
			247
		];
		this.tone(notes[this.step % notes.length], .22, "sine", .08, true);
		this.step += 1;
	}
	coin() {
		this.tone(880, .08, "sine", .12, false);
		this.tone(1320, .1, "triangle", .06, false);
	}
	crash() {
		this.burst(.28, 180);
		this.tone(90, .18, "square", .08, false);
	}
	shield() {
		this.tone(520, .12, "sine", .1, false);
		this.tone(780, .16, "triangle", .08, false);
	}
	nitro() {
		this.tone(180, .25, "sawtooth", .07, false);
		this.tone(420, .2, "square", .04, false);
	}
	scrape() {
		this.burst(.08, 900);
	}
	tone(freq, dur, type, vol, music) {
		if (!this.ctx || !this.sfxBus || !this.musicBus) return;
		if (music && !this.musicOn) return;
		if (!music && !this.soundOn) return;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = type;
		osc.frequency.value = freq;
		const now = this.ctx.currentTime;
		gain.gain.setValueAtTime(1e-4, now);
		gain.gain.exponentialRampToValueAtTime(Math.max(.001, vol), now + .02);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + dur);
		osc.connect(gain);
		gain.connect(music ? this.musicBus : this.sfxBus);
		osc.start(now);
		osc.stop(now + dur + .02);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
		};
	}
	burst(dur, freq) {
		if (!this.ctx || !this.noise || !this.sfxBus || !this.soundOn) return;
		const src = this.ctx.createBufferSource();
		src.buffer = this.noise;
		const filter = this.ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = freq;
		const gain = this.ctx.createGain();
		const now = this.ctx.currentTime;
		gain.gain.setValueAtTime(.18, now);
		gain.gain.exponentialRampToValueAtTime(1e-4, now + dur);
		src.connect(filter);
		filter.connect(gain);
		gain.connect(this.sfxBus);
		src.start(now);
		src.stop(now + dur);
		src.onended = () => {
			src.disconnect();
			filter.disconnect();
			gain.disconnect();
		};
	}
};
var STORAGE_KEY = "mountain-rush-gm-v1";
var WEATHERS = [
	"auto",
	"sunrise",
	"day",
	"sunset",
	"night",
	"fog",
	"storm"
];
function todayKey() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}
function num(v, fallback) {
	return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}
function clamp$1(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
/**
* Browser port of the Unity GameManager: one persistent profile
* (coins, nitro, shield, settings, daily gift, win rewards).
*/
var GameManager = class GameManager {
	static Instance = new GameManager();
	totalCoins = 1e3;
	nitroBoostCount = 2;
	shieldCount = 1;
	isSoundOn = true;
	isMusicOn = true;
	isNotificationOn = true;
	useTiltSteering = false;
	steeringSensitivity = 1;
	dailyGiftAmount = 250;
	lastGiftDate = "";
	ownedCars = ["red"];
	selectedCar = "red";
	selectedLevel = 1;
	unlockedLevel = 1;
	best = {};
	camera = "chase";
	weather = "auto";
	listeners = /* @__PURE__ */ new Set();
	subscribe(fn) {
		this.listeners.add(fn);
		return () => this.listeners.delete(fn);
	}
	emit() {
		for (const fn of this.listeners) fn();
	}
	LoadGameData() {
		if (typeof window === "undefined") return;
		try {
			const raw = localStorage.getItem(STORAGE_KEY);
			if (!raw) {
				this.SaveGameData();
				return;
			}
			const data = JSON.parse(raw);
			this.totalCoins = Math.max(0, Math.round(num(data.totalCoins, 1e3)));
			this.nitroBoostCount = Math.max(0, Math.round(num(data.nitroBoostCount, 2)));
			this.shieldCount = Math.max(0, Math.round(num(data.shieldCount, 1)));
			this.isSoundOn = data.isSoundOn !== false;
			this.isMusicOn = data.isMusicOn !== false;
			this.isNotificationOn = data.isNotificationOn !== false;
			this.useTiltSteering = data.useTiltSteering === true;
			this.steeringSensitivity = clamp$1(num(data.steeringSensitivity, 1), .5, 2);
			this.dailyGiftAmount = Math.max(0, Math.round(num(data.dailyGiftAmount, 250)));
			this.lastGiftDate = typeof data.lastGiftDate === "string" ? data.lastGiftDate : "";
			this.ownedCars = Array.isArray(data.ownedCars) && data.ownedCars.length > 0 ? data.ownedCars.map(String) : ["red"];
			if (!this.ownedCars.includes("red")) this.ownedCars.unshift("red");
			this.selectedCar = typeof data.selectedCar === "string" ? data.selectedCar : "red";
			if (!this.ownedCars.includes(this.selectedCar)) this.selectedCar = "red";
			this.selectedLevel = clamp$1(Math.round(num(data.selectedLevel, 1)), 1, 30);
			this.unlockedLevel = clamp$1(Math.round(num(data.unlockedLevel, 1)), 1, 30);
			this.best = data.best && typeof data.best === "object" ? data.best : {};
			this.camera = data.camera === "hood" ? "hood" : "chase";
			this.weather = WEATHERS.includes(data.weather) ? data.weather : "auto";
		} catch {}
		this.emit();
	}
	SaveGameData() {
		if (typeof window === "undefined") return;
		const data = {
			version: 1,
			totalCoins: this.totalCoins,
			nitroBoostCount: this.nitroBoostCount,
			shieldCount: this.shieldCount,
			isSoundOn: this.isSoundOn,
			isMusicOn: this.isMusicOn,
			isNotificationOn: this.isNotificationOn,
			useTiltSteering: this.useTiltSteering,
			steeringSensitivity: this.steeringSensitivity,
			dailyGiftAmount: this.dailyGiftAmount,
			lastGiftDate: this.lastGiftDate,
			ownedCars: this.ownedCars,
			selectedCar: this.selectedCar,
			selectedLevel: this.selectedLevel,
			unlockedLevel: this.unlockedLevel,
			best: this.best,
			camera: this.camera,
			weather: this.weather
		};
		localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
		this.emit();
	}
	ToggleSound(status) {
		this.isSoundOn = status;
		this.SaveGameData();
	}
	ToggleMusic(status) {
		this.isMusicOn = status;
		this.SaveGameData();
	}
	ToggleNotification(status) {
		this.isNotificationOn = status;
		this.SaveGameData();
	}
	SetSteeringMode(isTilt) {
		this.useTiltSteering = isTilt;
		this.SaveGameData();
	}
	SetSensitivity(value) {
		this.steeringSensitivity = clamp$1(value, .5, 2);
		this.SaveGameData();
	}
	giftAvailable() {
		return this.lastGiftDate !== todayKey();
	}
	ClaimDailyGift() {
		if (!this.giftAvailable()) return "আজকের ডেইলি গিফট নেওয়া হয়ে গেছে। কাল আবার এসো।";
		this.totalCoins += this.dailyGiftAmount;
		this.lastGiftDate = todayKey();
		this.SaveGameData();
		return `Daily Gift Claimed! +${this.dailyGiftAmount} Coins`;
	}
	GrantLevelWinReward(levelNumber) {
		const coinReward = 200 + levelNumber * 50;
		this.totalCoins += coinReward;
		const randomGift = 1 + Math.floor(Math.random() * 3);
		let bonusItem = "";
		if (randomGift === 1) {
			this.nitroBoostCount += 1;
			bonusItem = "1x Turbo Nitro Boost";
		} else if (randomGift === 2) {
			this.shieldCount += 1;
			bonusItem = "1x Rock Shield (পাথর থেকে বাঁচাবে)";
		} else {
			this.totalCoins += 150;
			bonusItem = "Extra 150 Bonus Coins!";
		}
		this.SaveGameData();
		return `তুমি জিতেছ: ${coinReward} কয়েন এবং উপহার হিসেবে পেয়েছ: ${bonusItem}`;
	}
	AddCoins(amount) {
		this.totalCoins = Math.max(0, this.totalCoins + Math.round(amount));
		this.SaveGameData();
	}
	TrySpend(amount) {
		if (this.totalCoins < amount) return false;
		this.totalCoins -= amount;
		this.SaveGameData();
		return true;
	}
	UseNitro() {
		if (this.nitroBoostCount <= 0) return false;
		this.nitroBoostCount -= 1;
		this.SaveGameData();
		return true;
	}
	UseShield() {
		if (this.shieldCount <= 0) return false;
		this.shieldCount -= 1;
		this.SaveGameData();
		return true;
	}
	ResetProgress() {
		Object.assign(this, {
			totalCoins: 1e3,
			nitroBoostCount: 2,
			shieldCount: 1,
			lastGiftDate: "",
			ownedCars: ["red"],
			selectedCar: "red",
			selectedLevel: 1,
			unlockedLevel: 1,
			best: {}
		});
		this.SaveGameData();
	}
};
var PRESETS = [
	{
		en: "Green Valley",
		bn: "সবুজ উপত্যকা",
		weather: "sunrise"
	},
	{
		en: "Mountain Road",
		bn: "পাহাড়ি রাস্তা",
		weather: "day"
	},
	{
		en: "Dangerous Hill",
		bn: "বিপজ্জনক পাহাড়",
		weather: "fog"
	},
	{
		en: "Bridge Mountain",
		bn: "সেতুর পাহাড়",
		weather: "sunset"
	},
	{
		en: "Night Ridge",
		bn: "রাতের পাহাড়",
		weather: "night"
	},
	{
		en: "Extreme Mountain",
		bn: "চরম পাহাড়",
		weather: "storm"
	}
];
var SUFFIX = [
	"",
	" II",
	" III",
	" IV",
	" V"
];
function getLevel(id) {
	const i = Math.max(1, Math.min(30, Math.round(id)));
	const preset = PRESETS[(i - 1) % PRESETS.length];
	const cycle = Math.floor((i - 1) / PRESETS.length);
	const suffix = SUFFIX[cycle] ?? ` ${cycle + 1}`;
	return {
		id: i,
		name: `${preset.en}${suffix}`,
		bn: `${preset.bn}${suffix}`,
		weather: preset.weather,
		seed: 1e3 + i * 97,
		segments: 58 + i * 3,
		curve: .09 + i * .0055,
		climb: .16 + i % 6 * .028,
		width: Math.max(6.3, 8.5 - i * .055),
		obstacleRate: Math.min(.2, .055 + i * .0045),
		bridge: preset.weather === "sunset" ? .15 : .045 + cycle * .012,
		mud: .025 + i * .002,
		broken: i < 4 ? 0 : .018 + cycle * .008
	};
}
var WEATHER_LABEL = {
	sunrise: "সূর্যোদয়",
	day: "দিন",
	sunset: "সন্ধ্যা",
	night: "রাত",
	fog: "কুয়াশা",
	storm: "বৃষ্টি"
};
function mulberry32(seed) {
	let a = seed >>> 0;
	return () => {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function clamp(v, min, max) {
	return Math.max(min, Math.min(max, v));
}
function buildWorld(level) {
	const rng = mulberry32(level.seed);
	const n = level.segments;
	const kinds = Array.from({ length: n }, () => "road");
	const widths = Array.from({ length: n }, () => level.width);
	let cursor = 12;
	while (cursor < n - 10) {
		const roll = rng();
		if (roll < level.bridge) {
			const len = 5 + Math.floor(rng() * 4);
			for (let k = 0; k < len && cursor + k < n - 8; k++) {
				kinds[cursor + k] = "bridge";
				widths[cursor + k] = Math.max(5.1, level.width - 2.3);
			}
			cursor += len + 7;
		} else if (roll < level.bridge + level.mud) {
			for (let k = 0; k < 4 && cursor + k < n - 6; k++) kinds[cursor + k] = "mud";
			cursor += 8;
		} else if (roll < level.bridge + level.mud + level.broken) {
			for (let k = 0; k < 3 && cursor + k < n - 6; k++) {
				kinds[cursor + k] = "broken";
				widths[cursor + k] = Math.max(4.8, level.width - 1.6);
			}
			cursor += 8;
		} else if (rng() < .16) {
			kinds[cursor] = "narrow";
			widths[cursor] = Math.max(5.3, level.width - 1.7);
			if (cursor + 1 < n) {
				kinds[cursor + 1] = "narrow";
				widths[cursor + 1] = widths[cursor];
			}
			cursor += 6;
		} else cursor += 1;
	}
	const raw = [];
	let x = 0;
	let z = 0;
	let heading = 0;
	for (let i = 0; i < n; i++) {
		const turn = (rng() - .5) * 2 * level.curve;
		heading = clamp(heading + turn, -1.02, 1.02);
		x += -Math.sin(heading) * 12;
		z += -Math.cos(heading) * 12;
		const t = i / (n - 1);
		const y = i * level.climb + Math.sin(i * .31) * (2.4 + level.curve * 10) + Math.sin(t * Math.PI) * 5;
		raw.push({
			x,
			y,
			z,
			kind: kinds[i],
			width: widths[i]
		});
	}
	for (let pass = 0; pass < 2; pass++) {
		const ys = raw.map((p) => p.y);
		const ws = raw.map((p) => p.width);
		for (let i = 1; i < n - 1; i++) {
			ys[i] = (raw[i - 1].y + raw[i].y * 2 + raw[i + 1].y) / 4;
			if (raw[i].kind !== "bridge" && raw[i].kind !== "broken") ws[i] = (raw[i - 1].width + raw[i].width * 2 + raw[i + 1].width) / 4;
		}
		for (let i = 0; i < n; i++) {
			raw[i].y = ys[i];
			raw[i].width = ws[i];
		}
	}
	const track = raw.map((p, i) => {
		const i0 = Math.max(0, i - 1);
		const i1 = Math.min(n - 1, i + 1);
		let tx = raw[i1].x - raw[i0].x;
		let tz = raw[i1].z - raw[i0].z;
		const len = Math.hypot(tx, tz) || 1;
		tx /= len;
		tz /= len;
		return {
			x: p.x,
			y: p.y,
			z: p.z,
			tx,
			tz,
			rx: -tz,
			rz: tx,
			width: p.width,
			kind: p.kind
		};
	});
	let length = 0;
	for (let i = 0; i < n - 1; i++) length += Math.hypot(track[i + 1].x - track[i].x, track[i + 1].z - track[i].z);
	const obstacles = [];
	const palette = [
		"rock",
		"log",
		"block",
		"pit",
		"mud",
		"tree"
	];
	for (let i = 14; i < n - 8; i++) {
		if (rng() > level.obstacleRate) continue;
		const p = track[i];
		if (p.kind === "bridge") continue;
		const off = (rng() < .5 ? -1 : 1) * (.35 + rng() * p.width * .22);
		const kind = palette[Math.floor(rng() * palette.length)];
		const radius = kind === "pit" ? 1.65 : kind === "mud" ? 2.15 : kind === "log" ? 1.25 : kind === "block" ? 1.15 : 1.05;
		obstacles.push({
			kind,
			x: p.x + p.rx * off,
			y: p.y,
			z: p.z + p.rz * off,
			yaw: Math.atan2(-p.tx, -p.tz),
			radius,
			solid: kind === "rock" || kind === "log" || kind === "block" || kind === "tree"
		});
		if (obstacles.length >= 40) break;
	}
	const coins = [];
	for (let i = 6; i < n - 4; i += 4) {
		const p = track[i];
		const side = i / 4 % 2 === 0 ? -1.35 : 1.35;
		const cx = p.x + p.rx * side;
		const cz = p.z + p.rz * side;
		if (obstacles.some((o) => (o.x - cx) ** 2 + (o.z - cz) ** 2 < 10)) continue;
		coins.push({
			x: cx,
			y: p.y + 1.15,
			z: cz
		});
	}
	return {
		track,
		length,
		obstacles,
		coins
	};
}
function sampleTrack(track, x, z) {
	const n = track.length;
	let best = Infinity;
	let bi = 0;
	let bt = 0;
	for (let i = 0; i < n - 1; i++) {
		const a = track[i];
		const b = track[i + 1];
		const abx = b.x - a.x;
		const abz = b.z - a.z;
		const ab2 = abx * abx + abz * abz;
		let t = ab2 > 1e-6 ? ((x - a.x) * abx + (z - a.z) * abz) / ab2 : 0;
		if (t < 0) t = 0;
		else if (t > 1) t = 1;
		const px = a.x + abx * t;
		const pz = a.z + abz * t;
		const d2 = (x - px) ** 2 + (z - pz) ** 2;
		if (d2 < best) {
			best = d2;
			bi = i;
			bt = t;
		}
	}
	const a = track[bi];
	const b = track[Math.min(n - 1, bi + 1)];
	const px = a.x + (b.x - a.x) * bt;
	const pz = a.z + (b.z - a.z) * bt;
	const py = a.y + (b.y - a.y) * bt;
	const tx = b.x - a.x;
	const tz = b.z - a.z;
	const horiz = Math.hypot(tx, tz) || 1;
	const tnx = tx / horiz;
	const tnz = tz / horiz;
	const rx = -tnz;
	const rz = tnx;
	const lateral = (x - px) * rx + (z - pz) * rz;
	return {
		x: px,
		y: py,
		z: pz,
		tx: tnx,
		tz: tnz,
		rx,
		rz,
		width: a.width + (b.width - a.width) * bt,
		kind: bt < .5 ? a.kind : b.kind,
		lateral,
		dist: Math.sqrt(best),
		grad: (b.y - a.y) / horiz,
		s: (bi + bt) / (n - 1),
		yaw: Math.atan2(-tnx, -tnz)
	};
}
function pointAlong(track, s) {
	const n = track.length;
	const f = clamp(s, 0, .999) * (n - 1);
	const i = Math.floor(f);
	const t = f - i;
	const a = track[i];
	const b = track[Math.min(n - 1, i + 1)];
	return {
		x: a.x + (b.x - a.x) * t,
		y: a.y + (b.y - a.y) * t,
		z: a.z + (b.z - a.z) * t,
		tx: a.tx,
		tz: a.tz,
		rx: a.rx,
		rz: a.rz,
		yaw: Math.atan2(-a.tx, -a.tz)
	};
}
var WEATHER = {
	sunrise: {
		sky: 15905155,
		fog: 15188900,
		hemi: 16765096,
		ground: 4020794,
		sun: 16756832,
		amb: .62,
		sunI: 1.35,
		near: 36,
		far: 150
	},
	day: {
		sky: 9357039,
		fog: 12966092,
		hemi: 14150911,
		ground: 4877125,
		sun: 16774365,
		amb: .72,
		sunI: 1.45,
		near: 48,
		far: 190
	},
	sunset: {
		sky: 14711381,
		fog: 14262410,
		hemi: 16757145,
		ground: 3814184,
		sun: 16742981,
		amb: .5,
		sunI: 1.15,
		near: 30,
		far: 140
	},
	night: {
		sky: 461590,
		fog: 1185830,
		hemi: 3359846,
		ground: 792082,
		sun: 10401512,
		amb: .42,
		sunI: .38,
		near: 24,
		far: 120
	},
	fog: {
		sky: 12963282,
		fog: 14015960,
		hemi: 15199978,
		ground: 6976876,
		sun: 16777215,
		amb: .62,
		sunI: .42,
		near: 14,
		far: 62
	},
	storm: {
		sky: 1778736,
		fog: 2765890,
		hemi: 5596791,
		ground: 1317912,
		sun: 12043217,
		amb: .34,
		sunI: .4,
		near: 18,
		far: 90
	}
};
var ROAD_COLOR = {
	road: [
		.23,
		.25,
		.27
	],
	bridge: [
		.38,
		.34,
		.28
	],
	mud: [
		.32,
		.22,
		.13
	],
	broken: [
		.16,
		.15,
		.14
	],
	narrow: [
		.26,
		.26,
		.28
	]
};
var GameEngine = class {
	host;
	hooks;
	canvas;
	renderer = null;
	scene = new Scene();
	camera = new PerspectiveCamera(68, 1, .1, 500);
	timer = new Timer();
	audio = new RaceAudio();
	world = new Group();
	disposables = [];
	hemi = new HemisphereLight(14150911, 4877125, .7);
	sun = new DirectionalLight(16774365, 1.3);
	carRoot = new Group();
	wheels = [];
	frontPivots = [];
	shieldMesh = null;
	flame = null;
	spots = [];
	rain = null;
	rainPositions = null;
	coinMesh = null;
	coinTaken = [];
	coinBase = [];
	obstacles = [];
	track = [];
	length = 400;
	level = getLevel(1);
	car = getCar("red");
	sample = null;
	dummy = new Object3D();
	camPos = new Vector3(0, 8, 16);
	look = new Vector3();
	lookSmooth = new Vector3();
	camReady = false;
	minimap = null;
	minimapAcc = 0;
	dead = false;
	phase = "menu";
	acc = 0;
	hudAcc = 0;
	previewS = .02;
	keys = /* @__PURE__ */ new Set();
	injected = /* @__PURE__ */ new Set();
	held = {
		left: false,
		right: false,
		throttle: false,
		brake: false,
		reverse: false,
		handbrake: false
	};
	steerOverride = null;
	useOverride = false;
	tilt = 0;
	x = 0;
	y = 0;
	z = 0;
	yaw = 0;
	speed = 0;
	lat = 0;
	steerVisual = 0;
	wheelSpin = 0;
	progress = 0;
	time = 0;
	crashes = 0;
	coinsRun = 0;
	drift = 0;
	nitroTimer = 0;
	invuln = 0;
	shake = 0;
	scrapeCd = 0;
	finished = false;
	wrongWay = false;
	clock = 0;
	constructor(host, hooks) {
		this.host = host;
		this.hooks = hooks;
		this.canvas = document.createElement("canvas");
		this.canvas.style.position = "absolute";
		this.canvas.style.inset = "0";
		this.canvas.style.width = "100%";
		this.canvas.style.height = "100%";
		this.canvas.style.display = "block";
		this.canvas.style.pointerEvents = "none";
		this.host.appendChild(this.canvas);
		this.scene.add(this.world);
		this.scene.add(this.carRoot);
		this.scene.add(this.hemi);
		this.sun.position.set(30, 40, 12);
		this.scene.add(this.sun);
		this.scene.add(this.sun.target);
		this.scene.fog = new Fog(12966092, 40, 180);
		try {
			this.renderer = new WebGLRenderer({
				canvas: this.canvas,
				antialias: true,
				alpha: false,
				powerPreference: "high-performance"
			});
		} catch {
			this.hooks.onBootError("এই ডিভাইসে 3D চালু হয়নি।");
			return;
		}
		this.renderer.outputColorSpace = SRGBColorSpace;
		this.renderer.toneMapping = 4;
		this.renderer.toneMappingExposure = 1.05;
		this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
		this.timer.connect(document);
		this.resize();
		this.bindInput();
		window.__controlsTest = {
			getYaw: () => this.yaw,
			getSpeed: () => this.speed,
			setKeys: (codes) => {
				this.injected = new Set(codes);
			},
			setSteer: (v) => {
				this.steerOverride = Math.max(-1, Math.min(1, v));
				this.useOverride = true;
			}
		};
		this.boot();
		this.renderer.setAnimationLoop(this.frame);
	}
	boot() {
		const gm = GameManager.Instance;
		this.car = getCar(gm.selectedCar);
		this.loadLevel(gm.selectedLevel);
		this.audio.setFlags(gm.isSoundOn, gm.isMusicOn);
	}
	dispose() {
		this.dead = true;
		this.renderer?.setAnimationLoop(null);
		window.removeEventListener("keydown", this.onKeyDown);
		window.removeEventListener("keyup", this.onKeyUp);
		window.removeEventListener("blur", this.onBlur);
		document.removeEventListener("visibilitychange", this.onVis);
		window.removeEventListener("deviceorientation", this.onOrient);
		window.removeEventListener("pointerdown", this.onPointer);
		window.removeEventListener("resize", this.resize);
		this.clearWorld();
		this.renderer?.dispose();
		this.canvas.remove();
		if (window.__controlsTest?.getYaw === this.yawReader) delete window.__controlsTest;
	}
	yawReader = () => this.yaw;
	setMinimap(canvas) {
		this.minimap = canvas;
	}
	setHeld(action, down) {
		this.held[action] = down;
	}
	previewLevel(id) {
		if (this.phase === "race") return;
		const gm = GameManager.Instance;
		gm.selectedLevel = id;
		gm.SaveGameData();
		this.loadLevel(id);
		this.phase = "menu";
	}
	setCar(id) {
		const gm = GameManager.Instance;
		gm.selectedCar = id;
		gm.SaveGameData();
		this.car = getCar(id);
		this.rebuildCar();
		this.placeCarAtStart(false);
	}
	applyAudio() {
		const gm = GameManager.Instance;
		this.audio.setFlags(gm.isSoundOn, gm.isMusicOn);
	}
	startRace() {
		const gm = GameManager.Instance;
		this.audio.unlock();
		if (this.level.id !== gm.selectedLevel || this.car.id !== gm.selectedCar) {
			this.car = getCar(gm.selectedCar);
			this.loadLevel(gm.selectedLevel);
		}
		this.placeCarAtStart(true);
		this.time = 0;
		this.crashes = 0;
		this.coinsRun = 0;
		this.drift = 0;
		this.nitroTimer = 0;
		this.invuln = .4;
		this.shake = 0;
		this.finished = false;
		this.wrongWay = false;
		this.coinTaken.fill(false);
		this.phase = "race";
		this.camReady = false;
		this.pushHud();
	}
	pause() {
		if (this.phase === "race") this.phase = "pause";
	}
	resume() {
		if (this.phase === "pause") this.phase = "race";
	}
	toMenu() {
		this.phase = "menu";
		this.speed = 0;
		this.camReady = false;
	}
	activateNitro() {
		if (this.phase !== "race" || this.nitroTimer > 0) return;
		const gm = GameManager.Instance;
		if (!gm.UseNitro()) {
			if (gm.isNotificationOn) this.hooks.onNotice("নাইট্রো শেষ");
			return;
		}
		this.nitroTimer = 2.4;
		this.audio.nitro();
		if (gm.isNotificationOn) this.hooks.onNotice("টার্বো নাইট্রো!");
	}
	rescue() {
		if (this.phase !== "race" && this.phase !== "pause") return;
		this.respawn(false);
	}
	bindInput() {
		window.addEventListener("keydown", this.onKeyDown);
		window.addEventListener("keyup", this.onKeyUp);
		window.addEventListener("blur", this.onBlur);
		document.addEventListener("visibilitychange", this.onVis);
		window.addEventListener("deviceorientation", this.onOrient);
		window.addEventListener("pointerdown", this.onPointer);
		window.addEventListener("resize", this.resize);
	}
	onPointer = () => this.audio.unlock();
	onKeyDown = (event) => {
		this.keys.add(event.code);
		if ([
			"ArrowUp",
			"ArrowDown",
			"ArrowLeft",
			"ArrowRight",
			"Space"
		].includes(event.code)) event.preventDefault();
		if ((event.code === "KeyN" || event.code === "ShiftLeft" || event.code === "ShiftRight") && !event.repeat) this.activateNitro();
	};
	onKeyUp = (event) => {
		this.keys.delete(event.code);
	};
	onBlur = () => {
		this.keys.clear();
		Object.keys(this.held).forEach((key) => {
			this.held[key] = false;
		});
	};
	onVis = () => {
		if (document.visibilityState === "visible") this.audio.resume();
		else this.onBlur();
	};
	onOrient = (event) => {
		const gamma = event.gamma ?? 0;
		this.tilt = Math.max(-1, Math.min(1, -gamma / 26));
	};
	resize = () => {
		if (!this.renderer) return;
		const w = this.host.clientWidth || 1;
		const h = this.host.clientHeight || 1;
		this.renderer.setSize(w, h, false);
		this.camera.aspect = w / Math.max(1, h);
		this.camera.updateProjectionMatrix();
	};
	frame = (stamp) => {
		if (this.dead || !this.renderer) return;
		this.timer.update(stamp);
		const frameDt = Math.min(this.timer.getDelta(), .05);
		this.clock += frameDt;
		this.acc += frameDt;
		if (this.acc > .12) this.acc = .12;
		const step = 1 / 60;
		let guard = 0;
		while (this.acc >= step && guard < 4) {
			this.simulate(step);
			this.acc -= step;
			guard += 1;
		}
		this.animateWorld(frameDt);
		this.updateCamera(frameDt);
		this.audio.updateEngine(this.speed, this.phase === "race" && this.input().throttle ? 1 : 0, this.phase === "race");
		this.audio.updateMusic(frameDt, true);
		this.hudAcc += frameDt;
		if (this.hudAcc > .1) {
			this.hudAcc = 0;
			this.pushHud();
		}
		this.minimapAcc += frameDt;
		if (this.minimapAcc > .12) {
			this.minimapAcc = 0;
			this.drawMinimap();
		}
		this.renderer.render(this.scene, this.camera);
	};
	input() {
		const down = (code) => this.keys.has(code) || this.injected.has(code);
		let steer = 0;
		if (this.held.left || down("KeyA") || down("ArrowLeft")) steer += 1;
		if (this.held.right || down("KeyD") || down("ArrowRight")) steer -= 1;
		const gm = GameManager.Instance;
		if (gm.useTiltSteering) steer += this.tilt;
		steer *= gm.steeringSensitivity;
		if (this.useOverride && this.steerOverride !== null) steer = this.steerOverride;
		steer = Math.max(-1, Math.min(1, steer));
		return {
			throttle: this.held.throttle || down("KeyW") || down("ArrowUp") ? 1 : 0,
			brake: this.held.brake || down("KeyS") || down("ArrowDown") ? 1 : 0,
			reverse: this.held.reverse || down("KeyR") ? 1 : 0,
			hand: this.held.handbrake || down("Space") ? 1 : 0,
			steer
		};
	}
	simulate(dt) {
		if (this.invuln > 0) this.invuln -= dt;
		if (this.scrapeCd > 0) this.scrapeCd -= dt;
		if (this.nitroTimer > 0) this.nitroTimer -= dt;
		if (this.phase !== "race") return;
		const input = this.input();
		const car = this.car;
		if (input.brake) this.speed -= car.brake * dt;
		else if (input.reverse) this.speed -= car.accel * .5 * dt;
		else if (input.throttle) this.speed += car.accel * dt;
		if (this.nitroTimer > 0) this.speed += car.accel * 1.35 * dt;
		const off = this.sample ? this.sample.dist > this.sample.width * .5 + .4 : false;
		const mud = this.sample?.kind === "mud";
		let drag = input.throttle > 0 || input.reverse > 0 ? .16 : .42;
		if (off) drag += 1.15;
		if (mud) drag += 1.35;
		this.speed -= this.speed * drag * dt;
		const cap = car.maxSpeed * (this.nitroTimer > 0 ? 1.28 : 1);
		this.speed = Math.max(-car.maxSpeed * .34, Math.min(cap, this.speed));
		const speedFactor = Math.max(.22, Math.min(1, Math.abs(this.speed) / 12));
		const reverse = this.speed >= 0 ? 1 : -1;
		const hand = input.hand > 0;
		this.yaw += input.steer * car.turn * speedFactor * reverse * (hand ? 1.35 : 1) * dt;
		const slip = Math.abs(input.steer) * Math.abs(this.speed) * (hand ? 2.1 : .18);
		this.lat += input.steer * slip * dt;
		const grip = car.grip * (hand ? .28 : 1) * (mud ? .5 : 1);
		this.lat *= Math.exp(-grip * 5.5 * dt);
		this.lat = Math.max(-14, Math.min(14, this.lat));
		if (hand && Math.abs(input.steer) > .35 && Math.abs(this.speed) > 9) this.drift = Math.min(1, this.drift + dt * .5);
		else if (!hand && this.drift > .4) {
			this.speed = Math.min(cap, this.speed + 7 + this.drift * 12);
			this.drift = 0;
			this.audio.nitro();
		} else this.drift = Math.max(0, this.drift - dt * .55);
		const fx = -Math.sin(this.yaw);
		const fz = -Math.cos(this.yaw);
		const rx = Math.cos(this.yaw);
		const rz = -Math.sin(this.yaw);
		this.x += (fx * this.speed + rx * this.lat) * dt;
		this.z += (fz * this.speed + rz * this.lat) * dt;
		let sm = sampleTrack(this.track, this.x, this.z);
		if (sm.kind !== "broken") {
			const limit = sm.width * .5 - .75;
			if (Math.abs(sm.lateral) > limit) {
				const sign = Math.sign(sm.lateral) || 1;
				const push = Math.abs(sm.lateral) - limit;
				this.x -= sm.rx * sign * push;
				this.z -= sm.rz * sign * push;
				this.lat *= -.15;
				if (push > .25 && Math.abs(this.speed) > 11 && this.scrapeCd <= 0) {
					this.speed *= .94;
					this.scrapeCd = .35;
					this.audio.scrape();
					this.shake = Math.max(this.shake, .12);
				}
				sm = sampleTrack(this.track, this.x, this.z);
			}
		}
		if (sm.dist > sm.width * .5 + 8 || sm.kind === "broken" && Math.abs(sm.lateral) > sm.width * .5 + 1.25 || sm.kind === "bridge" && Math.abs(sm.lateral) > sm.width * .5 + .85) {
			this.respawn(true);
			sm = sampleTrack(this.track, this.x, this.z);
		}
		this.resolveObstacles(sm);
		sm = sampleTrack(this.track, this.x, this.z);
		this.sample = sm;
		this.y = sm.y;
		this.collectCoins();
		if (sm.dist < sm.width && sm.s > this.progress && sm.s - this.progress < .06) this.progress = sm.s;
		const align = fx * sm.tx + fz * sm.tz;
		this.wrongWay = align < -.35 && this.speed > 5;
		this.time += dt;
		this.steerVisual += (input.steer - this.steerVisual) * Math.min(1, dt * 10);
		if (this.progress >= .988) this.finishRace();
	}
	resolveObstacles(sm) {
		let slow = sm.kind === "mud" ? 1.2 : 0;
		for (const obstacle of this.obstacles) {
			const dx = this.x - obstacle.x;
			const dz = this.z - obstacle.z;
			const dist = Math.hypot(dx, dz) || 1e-4;
			const reach = obstacle.radius + (obstacle.solid ? .85 : 0);
			if (dist > reach) continue;
			if (!obstacle.solid) {
				slow += obstacle.kind === "pit" ? 2.5 : 1.2;
				continue;
			}
			if (this.invuln <= 0) {
				const gm = GameManager.Instance;
				if (gm.shieldCount > 0) {
					gm.UseShield();
					this.invuln = 1.15;
					this.audio.shield();
					this.shake = Math.max(this.shake, .2);
					if (gm.isNotificationOn) this.hooks.onNotice("শিল্ড পাথর আটকালো");
				} else {
					this.crashes += 1;
					this.speed *= .42;
					this.invuln = .8;
					this.shake = .5;
					this.audio.crash();
				}
			}
			const overlap = reach - dist;
			this.x += dx / dist * overlap;
			this.z += dz / dist * overlap;
			this.lat += Math.sign(dx * sm.rx + dz * sm.rz) * 3;
		}
		if (slow > 0) this.speed -= this.speed * slow * (1 / 60);
	}
	collectCoins() {
		for (let i = 0; i < this.coinBase.length; i++) {
			if (this.coinTaken[i]) continue;
			const coin = this.coinBase[i];
			if ((coin.x - this.x) ** 2 + (coin.z - this.z) ** 2 > 2.4) continue;
			this.coinTaken[i] = true;
			this.coinsRun += 1;
			GameManager.Instance.AddCoins(5);
			this.audio.coin();
		}
	}
	respawn(countCrash) {
		const p = pointAlong(this.track, Math.max(.015, this.progress - .01));
		this.x = p.x;
		this.z = p.z;
		this.y = p.y;
		this.yaw = p.yaw;
		this.speed = 7;
		this.lat = 0;
		this.invuln = 1.1;
		this.shake = Math.max(this.shake, .25);
		if (countCrash) this.crashes += 1;
	}
	finishRace() {
		if (this.finished) return;
		this.finished = true;
		this.phase = "finish";
		this.speed = 0;
		const gm = GameManager.Instance;
		const stars = this.starCount();
		const key = String(this.level.id);
		const prev = gm.best[key];
		if (!prev || this.time < prev.time) gm.best[key] = {
			time: this.time,
			stars: Math.max(stars, prev?.stars ?? 0)
		};
		else if (stars > prev.stars) gm.best[key] = {
			time: prev.time,
			stars
		};
		gm.unlockedLevel = Math.max(gm.unlockedLevel, Math.min(30, this.level.id + 1));
		const rewardText = gm.GrantLevelWinReward(this.level.id);
		this.hooks.onFinish({
			level: this.level.id,
			time: this.time,
			crashes: this.crashes,
			coinsRun: this.coinsRun,
			stars,
			rewardText
		});
		this.pushHud();
	}
	starCount() {
		const par = this.length / 17;
		if (this.time < par && this.crashes <= 1) return 3;
		if (this.time < par * 1.4 && this.crashes <= 4) return 2;
		return 1;
	}
	pushHud() {
		this.hooks.onHud({
			speedKmh: Math.round(Math.abs(this.speed) * 3.6),
			time: this.time,
			progress: this.progress,
			coinsRun: this.coinsRun,
			crashes: this.crashes,
			drift: this.drift,
			wrongWay: this.wrongWay,
			nitroOn: this.nitroTimer > 0
		});
	}
	loadLevel(id) {
		this.level = getLevel(id);
		const built = buildWorld(this.level);
		this.track = built.track;
		this.length = built.length;
		this.obstacles = built.obstacles;
		this.clearWorld();
		this.scene.add(this.world);
		this.buildScenery(built.coins);
		this.rebuildCar();
		this.placeCarAtStart(false);
		this.progress = .02;
		this.previewS = .012;
		this.camReady = false;
		this.applySky();
	}
	applySky() {
		const gm = GameManager.Instance;
		const id = gm.weather === "auto" ? this.level.weather : gm.weather;
		const w = WEATHER[id];
		this.scene.background = new Color(w.sky);
		this.scene.fog = new Fog(w.fog, w.near, w.far);
		this.hemi.color.setHex(w.hemi);
		this.hemi.groundColor.setHex(w.ground);
		this.hemi.intensity = w.amb;
		this.sun.color.setHex(w.sun);
		this.sun.intensity = w.sunI;
		const night = id === "night" || id === "storm";
		for (const spot of this.spots) spot.intensity = night ? 7 : id === "sunset" || id === "fog" ? 2.2 : 0;
		if (this.rain) this.rain.visible = id === "storm";
	}
	refreshWeather() {
		this.applySky();
	}
	clearWorld() {
		if (this.rain) {
			this.scene.remove(this.rain);
			this.rain = null;
			this.rainPositions = null;
		}
		this.world.clear();
		for (const item of this.disposables) item.dispose();
		this.disposables = [];
		this.coinMesh = null;
	}
	trackDisposable(resource) {
		this.disposables.push(resource);
		return resource;
	}
	buildScenery(coins) {
		const pts = this.track;
		const road = this.ribbon(pts, (p) => p.width * .5, .02, (p) => ROAD_COLOR[p.kind], () => false);
		const shoulder = this.ribbon(pts, (p) => p.width * .5 + 2.4, -.05, () => [
			.13,
			.3,
			.16
		], (p) => p.kind === "bridge" || p.kind === "broken");
		const paint = this.ribbon(pts, () => .09, .06, () => [
			.78,
			.68,
			.32
		], (p) => p.kind === "broken");
		const roadMat = this.trackDisposable(new MeshStandardMaterial({
			vertexColors: true,
			roughness: .92,
			metalness: .04,
			side: 2
		}));
		const grassMat = this.trackDisposable(new MeshStandardMaterial({
			vertexColors: true,
			roughness: 1,
			metalness: 0,
			side: 2
		}));
		const paintMat = this.trackDisposable(new MeshStandardMaterial({
			vertexColors: true,
			roughness: .5,
			metalness: .1,
			side: 2
		}));
		this.world.add(new Mesh(road, roadMat), new Mesh(shoulder, grassMat), new Mesh(paint, paintMat));
		let minY = Infinity;
		let cx = 0;
		let cz = 0;
		for (const p of pts) {
			minY = Math.min(minY, p.y);
			cx += p.x;
			cz += p.z;
		}
		cx /= pts.length;
		cz /= pts.length;
		const groundGeo = this.trackDisposable(new CircleGeometry(520, 40));
		groundGeo.rotateX(-Math.PI / 2);
		const ground = new Mesh(groundGeo, this.trackDisposable(new MeshStandardMaterial({
			color: 793620,
			roughness: 1
		})));
		ground.position.set(cx, minY - 22, cz);
		const waterGeo = this.trackDisposable(new CircleGeometry(240, 32));
		waterGeo.rotateX(-Math.PI / 2);
		const water = new Mesh(waterGeo, this.trackDisposable(new MeshStandardMaterial({
			color: 1460316,
			roughness: .18,
			metalness: .35,
			transparent: true,
			opacity: .92
		})));
		water.position.set(cx, minY - 8, cz);
		this.world.add(ground, water);
		const coneGeo = this.trackDisposable(new ConeGeometry(22, 78, 6));
		const rockMat = this.trackDisposable(new MeshStandardMaterial({
			color: 2765616,
			roughness: .95
		}));
		const mossMat = this.trackDisposable(new MeshStandardMaterial({
			color: 1784360,
			roughness: 1
		}));
		for (let i = 0; i < 18; i++) {
			const angle = i / 18 * Math.PI * 2;
			const radius = 150 + i % 3 * 28;
			const mesh = new Mesh(coneGeo, i % 2 === 0 ? mossMat : rockMat);
			const h = 70 + i % 5 * 18;
			mesh.scale.set(1, h / 78, 1);
			mesh.position.set(cx + Math.cos(angle) * radius, minY - 18 + h * .35, cz + Math.sin(angle) * radius);
			this.world.add(mesh);
		}
		this.addForest(pts);
		this.addRails(pts);
		this.addObstacles();
		this.addCoins(coins);
		this.addDressing(pts, minY);
		this.addRain();
	}
	ribbon(pts, half, lift, color, skip) {
		const positions = [];
		const colors = [];
		const indices = [];
		for (const p of pts) {
			const hw = half(p);
			const c = color(p);
			positions.push(p.x + p.rx * hw, p.y + lift, p.z + p.rz * hw, p.x - p.rx * hw, p.y + lift, p.z - p.rz * hw);
			colors.push(c[0], c[1], c[2], c[0], c[1], c[2]);
		}
		for (let i = 0; i < pts.length - 1; i++) {
			if (skip(pts[i])) continue;
			const a = i * 2;
			indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
		}
		const geo = this.trackDisposable(new BufferGeometry());
		geo.setAttribute("position", new Float32BufferAttribute(positions, 3));
		geo.setAttribute("color", new Float32BufferAttribute(colors, 3));
		geo.setIndex(indices);
		geo.computeVertexNormals();
		return geo;
	}
	addForest(pts) {
		let count = 0;
		for (let i = 2; i < pts.length; i += 2) {
			if (pts[i].kind === "bridge" || pts[i].kind === "broken") continue;
			count += 2;
		}
		const trunkGeo = this.trackDisposable(new CylinderGeometry(.18, .26, 1.6, 5));
		const leafGeo = this.trackDisposable(new ConeGeometry(1.15, 2.8, 6));
		const trunkMat = this.trackDisposable(new MeshStandardMaterial({
			color: 5913384,
			roughness: 1
		}));
		const leafMat = this.trackDisposable(new MeshStandardMaterial({
			color: 2059066,
			roughness: .9
		}));
		const trunks = new InstancedMesh(trunkGeo, trunkMat, Math.max(1, count));
		const leaves = new InstancedMesh(leafGeo, leafMat, Math.max(1, count));
		let n = 0;
		for (let i = 2; i < pts.length; i += 2) {
			const p = pts[i];
			if (p.kind === "bridge" || p.kind === "broken") continue;
			for (const side of [-1, 1]) {
				const dist = p.width * .5 + 3.2 + i * side % 5;
				const jitter = i * 17 % 7 * .35;
				this.dummy.position.set(p.x + p.rx * side * dist, p.y + .8, p.z + p.rz * side * dist + jitter);
				this.dummy.scale.set(1, .8 + i % 4 * .18, 1);
				this.dummy.rotation.set(0, i, 0);
				this.dummy.updateMatrix();
				trunks.setMatrixAt(n, this.dummy.matrix);
				this.dummy.position.y = p.y + 2.5 + i % 3 * .2;
				this.dummy.scale.set(.85 + i % 3 * .15, .9 + i % 4 * .12, .85);
				this.dummy.updateMatrix();
				leaves.setMatrixAt(n, this.dummy.matrix);
				n += 1;
			}
		}
		trunks.count = n;
		leaves.count = n;
		trunks.instanceMatrix.needsUpdate = true;
		leaves.instanceMatrix.needsUpdate = true;
		this.world.add(trunks, leaves);
	}
	addRails(pts) {
		const geo = this.trackDisposable(new BoxGeometry(1, 1, 1));
		const mat = this.trackDisposable(new MeshStandardMaterial({
			color: 13218954,
			roughness: .6,
			metalness: .25
		}));
		const mesh = new InstancedMesh(geo, mat, pts.length * 2);
		let n = 0;
		for (let i = 0; i < pts.length - 1; i++) {
			const p = pts[i];
			if (p.kind === "broken") continue;
			const len = Math.hypot(pts[i + 1].x - p.x, pts[i + 1].z - p.z);
			for (const side of [-1, 1]) {
				const edge = p.width * .5 - .15;
				this.dummy.position.set(p.x + p.rx * side * edge, p.y + .38, p.z + p.rz * side * edge);
				this.dummy.lookAt(this.dummy.position.x + p.tx, this.dummy.position.y, this.dummy.position.z + p.tz);
				this.dummy.scale.set(.16, p.kind === "bridge" ? .7 : .42, len);
				this.dummy.updateMatrix();
				mesh.setMatrixAt(n, this.dummy.matrix);
				n += 1;
			}
		}
		mesh.count = n;
		mesh.instanceMatrix.needsUpdate = true;
		this.world.add(mesh);
	}
	addObstacles() {
		const rockGeo = this.trackDisposable(new DodecahedronGeometry(.85, 0));
		const rockMat = this.trackDisposable(new MeshStandardMaterial({
			color: 7169372,
			roughness: .95
		}));
		const logGeo = this.trackDisposable(new CylinderGeometry(.32, .38, 2.6, 7));
		logGeo.rotateZ(Math.PI / 2);
		const logMat = this.trackDisposable(new MeshStandardMaterial({
			color: 6964268,
			roughness: 1
		}));
		const blockMat = this.trackDisposable(new MeshStandardMaterial({
			color: 14132289,
			roughness: .7
		}));
		const darkMat = this.trackDisposable(new MeshStandardMaterial({
			color: 2236962,
			roughness: .8
		}));
		const pitGeo = this.trackDisposable(new CircleGeometry(1.55, 16));
		pitGeo.rotateX(-Math.PI / 2);
		const pitMat = this.trackDisposable(new MeshStandardMaterial({
			color: 1052943,
			roughness: 1
		}));
		const mudGeo = this.trackDisposable(new CircleGeometry(2.05, 18));
		mudGeo.rotateX(-Math.PI / 2);
		const mudMat = this.trackDisposable(new MeshStandardMaterial({
			color: 5913890,
			roughness: 1
		}));
		const trunkGeo = this.trackDisposable(new CylinderGeometry(.22, .3, 1.8, 6));
		const leafGeo = this.trackDisposable(new ConeGeometry(1, 2.2, 6));
		const leafMat = this.trackDisposable(new MeshStandardMaterial({
			color: 2980416,
			roughness: .9
		}));
		for (const obstacle of this.obstacles) if (obstacle.kind === "rock") {
			const mesh = new Mesh(rockGeo, rockMat);
			mesh.position.set(obstacle.x, obstacle.y + .55, obstacle.z);
			mesh.scale.set(1, .75 + obstacle.x % 1 * .2, 1);
			this.world.add(mesh);
		} else if (obstacle.kind === "log") {
			const mesh = new Mesh(logGeo, logMat);
			mesh.position.set(obstacle.x, obstacle.y + .38, obstacle.z);
			mesh.lookAt(obstacle.x + Math.sin(obstacle.yaw), obstacle.y + .38, obstacle.z + Math.cos(obstacle.yaw));
			this.world.add(mesh);
		} else if (obstacle.kind === "block") {
			const group = new Group();
			const a = new Mesh(new BoxGeometry(1.1, .7, .45), blockMat);
			const b = new Mesh(new BoxGeometry(1.1, .7, .45), darkMat);
			a.position.set(0, .4, -.28);
			b.position.set(0, .4, .28);
			group.add(a, b);
			group.position.set(obstacle.x, obstacle.y, obstacle.z);
			group.lookAt(obstacle.x + Math.sin(obstacle.yaw), obstacle.y, obstacle.z + Math.cos(obstacle.yaw));
			this.world.add(group);
			this.trackDisposable(a.geometry);
			this.trackDisposable(b.geometry);
		} else if (obstacle.kind === "pit") {
			const mesh = new Mesh(pitGeo, pitMat);
			mesh.position.set(obstacle.x, obstacle.y + .07, obstacle.z);
			this.world.add(mesh);
		} else if (obstacle.kind === "mud") {
			const mesh = new Mesh(mudGeo, mudMat);
			mesh.position.set(obstacle.x, obstacle.y + .05, obstacle.z);
			this.world.add(mesh);
		} else {
			const trunk = new Mesh(trunkGeo, logMat);
			const leaf = new Mesh(leafGeo, leafMat);
			trunk.position.set(obstacle.x, obstacle.y + .7, obstacle.z);
			trunk.rotation.z = 1.15;
			leaf.position.set(obstacle.x + .7, obstacle.y + .45, obstacle.z);
			this.world.add(trunk, leaf);
		}
	}
	addCoins(coins) {
		this.coinBase = coins;
		this.coinTaken = coins.map(() => false);
		const geo = this.trackDisposable(new OctahedronGeometry(.32, 0));
		const mat = this.trackDisposable(new MeshStandardMaterial({
			color: 14987610,
			metalness: .7,
			roughness: .25,
			emissive: 6965778,
			emissiveIntensity: .4
		}));
		const mesh = new InstancedMesh(geo, mat, Math.max(1, coins.length));
		mesh.count = coins.length;
		this.coinMesh = mesh;
		this.world.add(mesh);
		this.syncCoins(0);
	}
	syncCoins(time) {
		if (!this.coinMesh) return;
		for (let i = 0; i < this.coinBase.length; i++) {
			const coin = this.coinBase[i];
			const taken = this.coinTaken[i];
			this.dummy.position.set(coin.x, coin.y + Math.sin(time * 3 + i) * .12, coin.z);
			this.dummy.rotation.set(0, time * 1.6 + i, 0);
			this.dummy.scale.setScalar(taken ? .001 : 1);
			this.dummy.updateMatrix();
			this.coinMesh.setMatrixAt(i, this.dummy.matrix);
		}
		this.coinMesh.instanceMatrix.needsUpdate = true;
	}
	addDressing(pts, minY) {
		const fallMat = this.trackDisposable(new MeshStandardMaterial({
			color: 15202047,
			transparent: true,
			opacity: .45,
			roughness: .15,
			depthWrite: false
		}));
		const fallGeo = this.trackDisposable(new PlaneGeometry(2.2, 7));
		let falls = 0;
		for (let i = 8; i < pts.length && falls < 3; i += Math.floor(pts.length / 4)) {
			const p = pts[i];
			if (p.kind === "bridge") continue;
			const mesh = new Mesh(fallGeo, fallMat);
			mesh.position.set(p.x + p.rx * (p.width * .5 + 5), p.y + 2.2, p.z + p.rz * (p.width * .5 + 5));
			mesh.lookAt(p.x, p.y + 2, p.z);
			this.world.add(mesh);
			falls += 1;
		}
		const cloudGeo = this.trackDisposable(new SphereGeometry(7, 8, 6));
		const cloudMat = this.trackDisposable(new MeshStandardMaterial({
			color: 16250094,
			transparent: true,
			opacity: .55,
			depthWrite: false
		}));
		for (let i = 0; i < 7; i++) {
			const p = pts[Math.floor(i / 7 * (pts.length - 1))];
			const mesh = new Mesh(cloudGeo, cloudMat);
			mesh.scale.set(1.4, .38, 1);
			mesh.position.set(p.x + p.rx * (18 + i * 3), Math.max(p.y + 16, minY + 28), p.z + 6);
			mesh.name = "cloud";
			this.world.add(mesh);
		}
	}
	addRain() {
		const count = 700;
		const positions = new Float32Array(count * 3);
		for (let i = 0; i < count; i++) {
			positions[i * 3] = (Math.random() - .5) * 40;
			positions[i * 3 + 1] = Math.random() * 22;
			positions[i * 3 + 2] = (Math.random() - .5) * 40;
		}
		const geo = this.trackDisposable(new BufferGeometry());
		geo.setAttribute("position", new BufferAttribute(positions, 3));
		const mat = this.trackDisposable(new PointsMaterial({
			color: 14017774,
			size: .08,
			transparent: true,
			opacity: .65
		}));
		this.rain = new Points(geo, mat);
		this.rain.visible = false;
		this.rainPositions = positions;
		this.scene.add(this.rain);
	}
	rebuildCar() {
		const dumped = /* @__PURE__ */ new Set();
		this.carRoot.traverse((obj) => {
			const mesh = obj;
			if (!mesh.isMesh) return;
			if (mesh.geometry && !dumped.has(mesh.geometry)) {
				dumped.add(mesh.geometry);
				mesh.geometry.dispose();
			}
			const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
			for (const mat of mats) if (mat && !dumped.has(mat)) {
				dumped.add(mat);
				mat.dispose();
			}
		});
		this.carRoot.clear();
		this.wheels = [];
		this.frontPivots = [];
		this.spots = [];
		const color = new Color(this.car.color);
		const paint = new MeshStandardMaterial({
			color,
			metalness: .58,
			roughness: .32
		});
		const dark = new MeshStandardMaterial({
			color: 1315860,
			roughness: .72,
			metalness: .25
		});
		const glass = new MeshStandardMaterial({
			color: 12183295,
			roughness: .05,
			metalness: .15,
			transparent: true,
			opacity: .55
		});
		const gold = new MeshStandardMaterial({
			color: 14987610,
			metalness: .6,
			roughness: .3
		});
		const lamp = new MeshStandardMaterial({
			color: 16773580,
			emissive: 16764023,
			emissiveIntensity: 1.5
		});
		const tail = new MeshStandardMaterial({
			color: 16722474,
			emissive: 11145489,
			emissiveIntensity: 1.1
		});
		const body = new Mesh(new BoxGeometry(1.72, .38, 4.05), paint);
		body.position.set(0, .5, 0);
		const skirt = new Mesh(new BoxGeometry(1.8, .12, 4.12), dark);
		skirt.position.set(0, .28, 0);
		const cabin = new Mesh(new BoxGeometry(1.42, .4, 1.65), glass);
		cabin.position.set(0, .84, -.32);
		const hood = new Mesh(new BoxGeometry(1.5, .1, 1.25), paint);
		hood.position.set(0, .7, 1.05);
		const stripe = new Mesh(new BoxGeometry(.12, .05, 3.1), gold);
		stripe.position.set(0, .72, .15);
		const nose = new Mesh(new BoxGeometry(1.4, .16, .2), dark);
		nose.position.set(0, .42, 2.02);
		this.carRoot.add(body, skirt, cabin, hood, stripe, nose);
		const wheelGeo = new CylinderGeometry(.34, .34, .26, 14);
		wheelGeo.rotateZ(Math.PI / 2);
		for (const [wx, wz, front] of [
			[
				-.82,
				1.28,
				true
			],
			[
				.82,
				1.28,
				true
			],
			[
				-.82,
				-1.28,
				false
			],
			[
				.82,
				-1.28,
				false
			]
		]) {
			const pivot = new Group();
			pivot.position.set(wx, .34, wz);
			const wheel = new Mesh(wheelGeo, dark);
			pivot.add(wheel);
			this.carRoot.add(pivot);
			this.wheels.push(wheel);
			if (front) this.frontPivots.push(pivot);
		}
		const lampGeo = new BoxGeometry(.24, .12, .08);
		for (const side of [-.52, .52]) {
			const hl = new Mesh(lampGeo, lamp);
			hl.position.set(side, .55, 2.04);
			const tl = new Mesh(new BoxGeometry(.28, .1, .06), tail);
			tl.position.set(side, .58, -2.02);
			this.carRoot.add(hl, tl);
		}
		const flameGeo = new ConeGeometry(.28, 1.1, 8);
		flameGeo.rotateX(-Math.PI / 2);
		this.flame = new Mesh(flameGeo, new MeshStandardMaterial({
			color: 16747069,
			emissive: 16734751,
			emissiveIntensity: 2
		}));
		this.flame.position.set(0, .42, -2.35);
		this.flame.visible = false;
		this.carRoot.add(this.flame);
		const shield = new Mesh(new SphereGeometry(2.25, 18, 12), new MeshStandardMaterial({
			color: 9365503,
			transparent: true,
			opacity: .16,
			roughness: .05,
			depthWrite: false
		}));
		shield.position.y = .7;
		shield.visible = false;
		this.shieldMesh = shield;
		this.carRoot.add(shield);
		for (const side of [-.4, .4]) {
			const spot = new SpotLight(16773580, 0, 34, .55, .5, 1.1);
			spot.position.set(side, .6, 1.7);
			const target = new Object3D();
			target.position.set(side, .25, 14);
			this.carRoot.add(spot, target);
			spot.target = target;
			this.spots.push(spot);
		}
		this.applySky();
	}
	placeCarAtStart(boost) {
		const p = this.track[Math.min(5, this.track.length - 1)];
		if (!p) return;
		this.x = p.x;
		this.y = p.y;
		this.z = p.z;
		this.yaw = Math.atan2(-p.tx, -p.tz);
		this.speed = boost ? 0 : 0;
		this.lat = 0;
		this.progress = 5 / Math.max(1, this.track.length - 1);
		this.sample = sampleTrack(this.track, this.x, this.z);
		this.steerVisual = 0;
	}
	animateWorld(dt) {
		const fx = -Math.sin(this.yaw);
		const fz = -Math.cos(this.yaw);
		const sm = this.sample;
		const grad = sm ? sm.grad * (fx * sm.tx + fz * sm.tz) : 0;
		this.carRoot.position.set(this.x, this.y, this.z);
		this.carRoot.lookAt(this.x + fx * 8, this.y + grad * 8, this.z + fz * 8);
		this.carRoot.rotateZ(-this.steerVisual * .12);
		this.wheelSpin -= this.speed * dt * 2.6;
		for (const wheel of this.wheels) wheel.rotation.x = this.wheelSpin;
		for (const pivot of this.frontPivots) pivot.rotation.y = this.steerVisual * .32;
		if (this.shieldMesh) {
			const up = GameManager.Instance.shieldCount > 0;
			this.shieldMesh.visible = up;
			const s = 1 + Math.sin(this.clock * 4) * .03;
			this.shieldMesh.scale.setScalar(s);
		}
		if (this.flame) {
			this.flame.visible = this.nitroTimer > 0;
			this.flame.scale.set(1, 1, .7 + Math.sin(this.clock * 30) * .35);
		}
		this.syncCoins(this.clock);
		this.sun.position.set(this.x + 28, this.y + 42, this.z + 10);
		this.sun.target.position.set(this.x, this.y, this.z);
		if (this.rain && this.rain.visible && this.rainPositions) {
			this.rain.position.set(this.camera.position.x, this.camera.position.y - 4, this.camera.position.z);
			const arr = this.rainPositions;
			for (let i = 0; i < arr.length; i += 3) {
				arr[i + 1] -= dt * 22;
				if (arr[i + 1] < -8) arr[i + 1] = 14;
			}
			const attr = this.rain.geometry.getAttribute("position");
			attr.needsUpdate = true;
		}
		this.world.traverse((obj) => {
			if (obj.name === "cloud") obj.position.x += dt * .8;
		});
	}
	updateCamera(dt) {
		const fx = -Math.sin(this.yaw);
		const fz = -Math.cos(this.yaw);
		const gm = GameManager.Instance;
		const weather = gm.weather === "auto" ? this.level.weather : gm.weather;
		if (this.phase === "menu") {
			this.previewS += dt * .012;
			if (this.previewS > .62) this.previewS = .02;
			const a = pointAlong(this.track, this.previewS);
			const b = pointAlong(this.track, Math.min(.96, this.previewS + .045));
			this.camPos.lerp(new Vector3(a.x - a.tx * 14 + a.rx * 3, a.y + 7.2, a.z - a.tz * 14 + a.rz * 3), this.camReady ? 1 - Math.exp(-1.6 * dt) : 1);
			this.lookSmooth.lerp(new Vector3(b.x, b.y + 1.6, b.z), this.camReady ? 1 - Math.exp(-1.8 * dt) : 1);
			this.camReady = true;
		} else {
			const hood = gm.camera === "hood";
			const dist = weather === "fog" ? 8.2 : 11;
			const desired = hood ? new Vector3(this.x + fx * .2, this.y + 1.28, this.z + fz * .2) : new Vector3(this.x - fx * dist, this.y + 4.3, this.z - fz * dist);
			const lookAt = hood ? new Vector3(this.x + fx * 16, this.y + 1.05, this.z + fz * 16) : new Vector3(this.x + fx * 7, this.y + 1.25, this.z + fz * 7);
			const k = 1 - Math.exp(-(hood ? 8 : 4.5) * dt);
			if (!this.camReady) {
				this.camPos.copy(desired);
				this.lookSmooth.copy(lookAt);
				this.camReady = true;
			} else {
				this.camPos.lerp(desired, k);
				this.lookSmooth.lerp(lookAt, k);
			}
		}
		if (this.shake > 0) {
			this.shake = Math.max(0, this.shake - dt);
			this.camPos.x += (Math.random() - .5) * this.shake;
			this.camPos.y += (Math.random() - .5) * this.shake * .6;
		}
		this.camera.position.copy(this.camPos);
		this.camera.lookAt(this.lookSmooth);
		const fov = 66 + Math.min(14, Math.abs(this.speed) * .32) + (this.nitroTimer > 0 ? 6 : 0);
		this.camera.fov += (fov - this.camera.fov) * Math.min(1, dt * 3);
		this.camera.updateProjectionMatrix();
	}
	drawMinimap() {
		const canvas = this.minimap;
		if (!canvas || this.track.length < 2) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const w = canvas.width;
		const h = canvas.height;
		let minX = Infinity;
		let maxX = -Infinity;
		let minZ = Infinity;
		let maxZ = -Infinity;
		for (const p of this.track) {
			minX = Math.min(minX, p.x);
			maxX = Math.max(maxX, p.x);
			minZ = Math.min(minZ, p.z);
			maxZ = Math.max(maxZ, p.z);
		}
		const pad = 10;
		const s = Math.min((w - 20) / (maxX - minX || 1), (h - 20) / (maxZ - minZ || 1));
		ctx.clearRect(0, 0, w, h);
		ctx.fillStyle = "rgba(7,17,13,0.72)";
		ctx.fillRect(0, 0, w, h);
		ctx.beginPath();
		this.track.forEach((p, i) => {
			const X = pad + (p.x - minX) * s;
			const Y = pad + (p.z - minZ) * s;
			if (i === 0) ctx.moveTo(X, Y);
			else ctx.lineTo(X, Y);
		});
		ctx.strokeStyle = "#e4b15a";
		ctx.lineWidth = 2;
		ctx.stroke();
		ctx.fillStyle = "#e25b3a";
		ctx.beginPath();
		ctx.arc(pad + (this.x - minX) * s, pad + (this.z - minZ) * s, 3.5, 0, Math.PI * 2);
		ctx.fill();
	}
};
var EMPTY_HUD = {
	speedKmh: 0,
	time: 0,
	progress: 0,
	coinsRun: 0,
	crashes: 0,
	drift: 0,
	wrongWay: false,
	nitroOn: false
};
function formatTime(time) {
	const m = Math.floor(time / 60);
	const s = Math.floor(time % 60);
	const cs = Math.floor(time % 1 * 100);
	return `${m}:${s.toString().padStart(2, "0")}.${cs.toString().padStart(2, "0")}`;
}
function MountainRush() {
	const hostRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const pendingStart = (0, import_react.useRef)(false);
	const [screen, setScreen] = (0, import_react.useState)("menu");
	const [hud, setHud] = (0, import_react.useState)(EMPTY_HUD);
	const [result, setResult] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)(null);
	const [giftNote, setGiftNote] = (0, import_react.useState)(null);
	const [bootError, setBootError] = (0, import_react.useState)(null);
	const [profile, setProfile] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const gm = GameManager.Instance;
		const unsub = gm.subscribe(() => setProfile((n) => n + 1));
		gm.LoadGameData();
		const host = hostRef.current;
		if (!host) return unsub;
		const engine = new GameEngine(host, {
			onHud: setHud,
			onFinish: (next) => {
				setResult(next);
				setScreen("results");
			},
			onNotice: setNote,
			onBootError: setBootError
		});
		engineRef.current = engine;
		if (pendingStart.current) {
			pendingStart.current = false;
			engine.startRace();
			setScreen("race");
		}
		return () => {
			unsub();
			engine.dispose();
			engineRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!note) return;
		const id = window.setTimeout(() => setNote(null), 2400);
		return () => window.clearTimeout(id);
	}, [note]);
	const gm = GameManager.Instance;
	const level = getLevel(gm.selectedLevel);
	const car = getCar(gm.selectedCar);
	function start() {
		const engine = engineRef.current;
		if (!engine) {
			pendingStart.current = true;
			setScreen("race");
			return;
		}
		engine.startRace();
		setScreen("race");
	}
	function hold(action, down) {
		return (event) => {
			event.preventDefault();
			if (down) event.currentTarget.setPointerCapture(event.pointerId);
			engineRef.current?.setHeld(action, down);
		};
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: hostRef,
				className: "absolute inset-0"
			}),
			bootError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute inset-x-0 top-6 z-30 px-4 text-center text-sm text-gold",
				children: bootError
			}) : null,
			note && gm.isNotificationOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "absolute top-16 left-1/2 z-40 max-w-xs -translate-x-1/2 rounded-full border border-line bg-panel px-4 py-2 text-center text-sm text-ink",
				children: note
			}) : null,
			screen === "menu" || screen === "garage" || screen === "levels" || screen === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuChrome, {
				screen,
				setScreen,
				levelName: `${level.bn}`,
				levelEn: level.name,
				carName: car.bn,
				giftNote,
				onGift: () => setGiftNote(gm.ClaimDailyGift()),
				onStart: start,
				onSelectLevel: (id) => engineRef.current?.previewLevel(id),
				onSelectCar: (id) => engineRef.current?.setCar(id),
				onAudio: () => engineRef.current?.applyAudio(),
				onWeather: () => engineRef.current?.refreshWeather(),
				onReset: () => {
					GameManager.Instance.ResetProgress();
					engineRef.current?.previewLevel(1);
					engineRef.current?.setCar("red");
				}
			}) : null,
			screen === "race" || screen === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RaceHud, {
				hud,
				levelBn: level.bn,
				screen,
				onPause: () => {
					engineRef.current?.pause();
					setScreen("pause");
				},
				onResume: () => {
					engineRef.current?.resume();
					setScreen("race");
				},
				onQuit: () => {
					engineRef.current?.toMenu();
					setScreen("menu");
				},
				onNitro: () => engineRef.current?.activateNitro(),
				onRescue: () => engineRef.current?.rescue(),
				hold,
				mapRef: (node) => engineRef.current?.setMinimap(node)
			}) : null,
			screen === "results" && result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {
				result,
				onRetry: start,
				onNext: () => {
					const next = Math.min(30, result.level + 1);
					gm.selectedLevel = next;
					gm.SaveGameData();
					engineRef.current?.previewLevel(next);
					start();
				},
				onMenu: () => {
					engineRef.current?.toMenu();
					setScreen("menu");
				}
			}) : null
		]
	});
}
function Wallet() {
	const gm = GameManager.Instance;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex shrink-0 items-center gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 rounded-full border border-line bg-panel/90 px-2 py-1 text-xs text-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-3.5" }), gm.totalCoins]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 rounded-full border border-line bg-panel/90 px-2 py-1 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-3.5 text-gold" }), gm.nitroBoostCount]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1 rounded-full border border-line bg-panel/90 px-2 py-1 text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-3.5 text-pine" }), gm.shieldCount]
			})
		]
	});
}
function MenuChrome({ screen, setScreen, levelName, levelEn, carName, giftNote, onGift, onStart, onSelectLevel, onSelectCar, onAudio, onWeather, onReset }) {
	const gm = GameManager.Instance;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-20 flex flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scrim-top pointer-events-none absolute inset-x-0 top-0 h-36" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative flex flex-col gap-3 p-4 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs tracking-widest text-gold",
						children: "MOUNTAIN RUSH"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl leading-none text-ink sm:text-5xl",
						children: "Mountain Rush 3D"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "পাহাড়ি অ্যাডভেঞ্চার রেস"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scrim-bottom px-4 pt-16 pb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto w-full max-w-lg",
					children: [
						screen === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-line bg-panel/90 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-4 flex items-center justify-between gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-muted",
											children: ["পর্ব ", gm.selectedLevel]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-lg text-ink",
											children: levelName
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted",
											children: levelEn
										})
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-right",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-muted",
											children: "গাড়ি"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-display text-lg",
											children: carName
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onStart,
									className: "flex h-14 w-full flex-col items-center justify-center rounded-xl bg-ember text-bg",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-2xl leading-none",
										children: "Start"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-medium",
										children: "খেলো"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniButton, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mountain, { className: "size-4" }),
											label: "গ্যারেজ",
											onClick: () => setScreen("garage")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniButton, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-4" }),
											label: "পর্ব",
											onClick: () => setScreen("levels")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MiniButton, {
											icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }),
											label: "সেটিংস",
											onClick: () => setScreen("settings")
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onGift,
									className: "mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-line bg-panel-2 text-sm text-gold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { className: "size-4" }),
										"ডেইলি গিফট +",
										gm.dailyGiftAmount
									]
								}),
								giftNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-center text-sm text-ink",
									children: giftNote
								}) : null,
								gm.isNotificationOn && gm.giftAvailable() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-center text-xs text-muted",
									children: "আজকের উপহার অপেক্ষা করছে।"
								}) : null
							]
						}) : null,
						screen === "garage" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
							title: "গ্যারেজ",
							onBack: () => setScreen("menu"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "flex flex-col gap-2",
								children: CARS.map((item) => {
									const owned = gm.ownedCars.includes(item.id);
									const selected = gm.selectedCar === item.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: `rounded-xl border p-3 ${selected ? "border-gold bg-panel-2" : "border-line"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-10 shrink-0 rounded-lg border border-line",
													style: { background: item.color }
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0 flex-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "font-display text-lg leading-tight",
														children: item.bn
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs text-muted",
														children: item.name
													})]
												}),
												owned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => onSelectCar(item.id),
													className: "h-11 rounded-lg bg-pine px-3 text-sm text-ink",
													children: selected ? "নির্বাচিত" : "বেছে নাও"
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													disabled: gm.totalCoins < item.price,
													onClick: () => {
														if (!gm.TrySpend(item.price)) return;
														gm.ownedCars = [...gm.ownedCars, item.id];
														gm.SaveGameData();
														onSelectCar(item.id);
													},
													className: "h-11 rounded-lg bg-gold px-3 text-sm text-bg disabled:opacity-40",
													children: item.price
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 grid grid-cols-5 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													label: "স্পিড",
													value: statPercent(item.maxSpeed, 42)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													label: "অ্যাক্সেল",
													value: statPercent(item.accel, 23)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													label: "ব্রেক",
													value: statPercent(item.brake, 34)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													label: "হ্যান্ডল",
													value: statPercent(item.turn, 1.85)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
													label: "গ্রিপ",
													value: statPercent(item.grip, 1.12)
												})
											]
										})]
									}, item.id);
								})
							})
						}) : null,
						screen === "levels" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
							title: "পর্বসমূহ",
							onBack: () => setScreen("menu"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
								children: Array.from({ length: 30 }, (_, index) => {
									const id = index + 1;
									const def = getLevel(id);
									const locked = id > gm.unlockedLevel;
									const best = gm.best[String(id)];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: locked,
										onClick: () => onSelectLevel(id),
										className: `min-h-16 rounded-xl border p-2 text-left ${gm.selectedLevel === id ? "border-gold bg-panel-2" : "border-line"} disabled:opacity-45`,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex items-center justify-between text-xs text-muted",
												children: [
													"পর্ব ",
													id,
													locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: WEATHER_LABEL[def.weather] })
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 block text-sm leading-tight",
												children: def.bn
											}),
											best ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "mt-1 block text-xs text-gold",
												children: formatTime(best.time)
											}) : null
										]
									}, id);
								})
							})
						}) : null,
						screen === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
							title: "সেটিংস",
							onBack: () => setScreen("menu"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPanel, {
								onAudio,
								onWeather,
								onReset
							})
						}) : null
					]
				})
			})
		]
	});
}
function MiniButton({ icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex h-12 flex-col items-center justify-center gap-0.5 rounded-xl border border-line bg-panel-2 text-xs",
		children: [icon, label]
	});
}
function Bar({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-1 h-1.5 overflow-hidden rounded-full bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-gold",
			style: { width: `${value}%` }
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-center text-xs text-muted",
		children: label
	})] });
}
function Sheet({ title, onBack, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "max-h-[68dvh] overflow-y-auto rounded-2xl border border-line bg-panel/95 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "grid size-11 place-items-center rounded-xl border border-line",
				"aria-label": "ফিরে যাও",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: title
			})]
		}), children]
	});
}
function SettingsPanel({ onAudio, onWeather, onReset }) {
	const gm = GameManager.Instance;
	const weatherOptions = [
		{
			id: "auto",
			label: "লেভেল"
		},
		{
			id: "sunrise",
			label: WEATHER_LABEL.sunrise
		},
		{
			id: "day",
			label: WEATHER_LABEL.day
		},
		{
			id: "sunset",
			label: WEATHER_LABEL.sunset
		},
		{
			id: "night",
			label: WEATHER_LABEL.night
		},
		{
			id: "fog",
			label: WEATHER_LABEL.fog
		},
		{
			id: "storm",
			label: WEATHER_LABEL.storm
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				label: "সাউন্ড",
				on: gm.isSoundOn,
				icon: gm.isSoundOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }),
				onClick: () => {
					gm.ToggleSound(!gm.isSoundOn);
					onAudio();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				label: "মিউজিক",
				on: gm.isMusicOn,
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music, { className: "size-4" }),
				onClick: () => {
					gm.ToggleMusic(!gm.isMusicOn);
					onAudio();
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
				label: "নোটিফিকেশন",
				on: gm.isNotificationOn,
				icon: gm.isNotificationOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, { className: "size-4" }),
				onClick: () => gm.ToggleNotification(!gm.isNotificationOn)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm text-muted",
						children: "স্টিয়ারিং"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => gm.SetSteeringMode(false),
							className: `h-11 rounded-lg border text-sm ${gm.useTiltSteering ? "border-line" : "border-gold bg-panel-2"}`,
							children: "বাটন"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => void enableTilt(),
							className: `flex h-11 items-center justify-center gap-1 rounded-lg border text-sm ${gm.useTiltSteering ? "border-gold bg-panel-2" : "border-line"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-4" }), "টিল্ট"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-sm text-muted",
						children: [
							"সেন্সিটিভিটি ",
							gm.steeringSensitivity.toFixed(2),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "mt-2 w-full accent-gold",
								type: "range",
								min: .5,
								max: 2,
								step: .05,
								value: gm.steeringSensitivity,
								onChange: (event) => gm.SetSensitivity(Number(event.target.value))
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-muted",
					children: "ক্যামেরা"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2",
					children: ["chase", "hood"].map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							gm.camera = mode;
							gm.SaveGameData();
						},
						className: `h-11 rounded-lg border text-sm ${gm.camera === mode ? "border-gold bg-panel-2" : "border-line"}`,
						children: mode === "chase" ? "পিছন থেকে" : "হুড"
					}, mode))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-sm text-muted",
					children: "আবহাওয়া"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: weatherOptions.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							gm.weather = option.id;
							gm.SaveGameData();
							onWeather();
						},
						className: `h-10 rounded-lg border px-3 text-sm ${gm.weather === option.id ? "border-gold text-gold" : "border-line"}`,
						children: option.label
					}, option.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onReset,
				className: "h-11 rounded-xl border border-ember text-sm text-ember",
				children: "প্রোগ্রেস মুছে ফেলো"
			})
		]
	});
}
async function enableTilt() {
	const ctor = DeviceOrientationEvent;
	if (typeof ctor.requestPermission === "function") try {
		if (await ctor.requestPermission() !== "granted") return;
	} catch {
		return;
	}
	GameManager.Instance.SetSteeringMode(true);
}
function Toggle({ label, on, icon, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex h-12 items-center justify-between rounded-xl border border-line px-3 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-2",
			children: [icon, label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: on ? "text-gold" : "text-muted",
			children: on ? "চালু" : "বন্ধ"
		})]
	});
}
function RaceHud({ hud, levelBn, screen, onPause, onResume, onQuit, onNitro, onRescue, hold, mapRef }) {
	const gm = GameManager.Instance;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onPause,
						className: "grid size-11 place-items-center rounded-xl border border-line bg-panel/90",
						"aria-label": "পজ",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 rounded-xl border border-line bg-panel/90 px-3 py-2 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs text-muted",
							children: levelBn
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg tabular-nums",
							children: formatTime(hud.time)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-20 left-3 flex items-end gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl tabular-nums leading-none",
					children: hud.speedKmh
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "km/h"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
					ref: mapRef,
					width: 148,
					height: 96,
					className: "hidden rounded-lg border border-line sm:block"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-20 right-3 flex flex-col items-end gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onNitro,
						className: "pointer-events-auto inline-flex h-11 items-center gap-1 rounded-xl bg-gold px-3 text-sm text-bg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "size-4" }),
							"নাইট্রো ",
							gm.nitroBoostCount
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1 rounded-full bg-panel/90 px-2 py-1 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-3.5 text-pine" }), gm.shieldCount]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: onRescue,
						className: "pointer-events-auto inline-flex h-11 items-center gap-1 rounded-xl border border-line bg-panel/90 px-3 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "রেসকিউ"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-36 right-3 left-3 sm:left-40 sm:right-auto sm:w-48",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1.5 overflow-hidden rounded-full bg-panel",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-pine",
							style: { width: `${Math.round(hud.progress * 100)}%` }
						})
					}),
					hud.drift > .05 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 h-1.5 overflow-hidden rounded-full bg-panel",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-ember",
							style: { width: `${Math.round(hud.drift * 100)}%` }
						})
					}) : null,
					hud.wrongWay ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-ember",
						children: "উল্টো দিক"
					}) : null,
					hud.nitroOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-gold",
						children: "নাইট্রো"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "absolute bottom-4 left-4 hidden items-center gap-2 text-xs text-muted md:flex",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-4" }), "W অ্যাক্সেল · S ব্রেক · A/D স্টিয়ার · Space ড্রিফট · R রিভার্স · N নাইট্রো"]
			}),
			screen === "race" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto absolute inset-x-0 bottom-0 flex items-end justify-between gap-3 p-3 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
						label: "বাঁ",
						onDown: hold("left", true),
						onUp: hold("left", false)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
						label: "ডান",
						onDown: hold("right", true),
						onUp: hold("right", false)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-16 w-28 rounded-2xl bg-ember text-sm font-semibold text-bg",
						onPointerDown: hold("throttle", true),
						onPointerUp: hold("throttle", false),
						onPointerCancel: hold("throttle", false),
						children: "ACCEL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmallControl, {
								label: "BRAKE",
								action: "brake",
								hold
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmallControl, {
								label: "DRIFT",
								action: "handbrake",
								hold
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SmallControl, {
								label: "REV",
								action: "reverse",
								hold
							})
						]
					})]
				})]
			}) : null,
			screen === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto absolute inset-0 grid place-items-center bg-bg/70 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-2xl border border-line bg-panel p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl",
						children: "পজ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onResume,
							className: "h-12 rounded-xl bg-ember text-bg",
							children: "চালিয়ে যাও"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onQuit,
							className: "h-12 rounded-xl border border-line",
							children: "মেনু"
						})]
					})]
				})
			}) : null
		]
	});
}
function Control({ label, onDown, onUp }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "grid size-16 place-items-center rounded-2xl border border-line bg-panel/90 text-sm",
		onPointerDown: onDown,
		onPointerUp: onUp,
		onPointerCancel: onUp,
		onContextMenu: (event) => event.preventDefault(),
		children: label
	});
}
function SmallControl({ label, action, hold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "h-12 min-w-16 rounded-xl border border-line bg-panel/90 px-2 text-xs",
		onPointerDown: hold(action, true),
		onPointerUp: hold(action, false),
		onPointerCancel: hold(action, false),
		children: label
	});
}
function Results({ result, onRetry, onNext, onMenu }) {
	const level = getLevel(result.level);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 grid place-items-center bg-bg/75 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl border border-line bg-panel p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-gold",
					children: [
						"পর্ব ",
						result.level,
						" সম্পন্ন"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: level.bn
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex gap-1 text-gold",
					children: [
						1,
						2,
						3
					].map((star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `size-6 ${star <= result.stars ? "fill-gold" : "text-line"}` }, star))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-4 grid grid-cols-3 gap-2 text-center text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-panel-2 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "সময়"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums",
								children: formatTime(result.time)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-panel-2 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "কয়েন"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: result.coinsRun })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-panel-2 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "ক্র্যাশ"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: result.crashes })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm leading-relaxed",
					children: result.rewardText
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-2",
					children: [
						result.level < 30 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onNext,
							className: "h-12 rounded-xl bg-ember text-bg",
							children: "পরের পর্ব"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onRetry,
							className: "h-12 rounded-xl border border-line",
							children: "আবার"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onMenu,
							className: "h-12 rounded-xl border border-line",
							children: "মেনু"
						})
					]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MountainRush, {});
}
//#endregion
export { Home as component };
