//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-xCYGp_pF.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BxmpE3AW.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BxmpE3AW.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-2r_T0jRZ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
